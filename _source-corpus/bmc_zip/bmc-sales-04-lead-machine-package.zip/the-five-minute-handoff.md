# The Five-Minute Handoff

Yo! It's RyMac. Before anything else, the law that splits everything I
teach:

**Once a lead is generated, it is a sales problem.**

**Marketing gets the lead. Sales gets the money.**

Everything in the lead machine lives on the marketing side of that line.
Its only job is to make a stranger raise their hand. The moment somebody
replies "yes," congratulations: that's a lead, and per the law, it is now a
sales problem. This file is about the 5 minutes where that handoff wins or
dies.

## Rule 1: speed

A human reply within 5 minutes of theirs. After 5 minutes they're back on
a roof, in a meeting, gone. They didn't get less interested. They got busy,
and busy people don't circle back to strangers.

## Rule 2: the reply has 1 job

The 15-minute call. Not a pitch, not a PDF, not answering every question in
writing. 1 job: get the yes to 15 minutes. The framework takes it from
there (that's the first 3 lessons, and that's my department).

## How far speed and follow-up can actually go

At Woosender, my AI assistant worked the leads for me. Instant answers,
relentless follow-up. Prospects booked calls thinking they'd been texting
with me the whole time. So I'd open the call like this: "Hold on, hold on
one second. You haven't talked to me. You've been speaking with my AI
assistant. Let me catch up on your text messages real quick." You could see
the what-the-fuck in their head.

The machine didn't just book the call. It WAS the demo.

**It worked on you. Why won't it work for you?**

That 1 sentence closed more deals than any feature list I ever wrote. The
lesson isn't "go buy an AI assistant." The lesson is that speed plus
relentless follow-up is so rare it feels like magic to the prospect, and if
your product touches the way you reached them, your handoff can double as
your proof.

## Run this prompt

Paste this into your AI with this file:

```
My business: [WHAT YOU OFFER AND WHAT A FIRST CALL IS FOR]
Who answers replies today: [ME / A TEAMMATE / NOBODY YET] and where those
replies land: [INBOX, PHONE, CRM, ETC.]
My realistic availability: [WHEN YOU CAN ACTUALLY RESPOND, HONESTLY]
How I book calls now: [CALENDAR TOOL, BACK-AND-FORTH TEXTS, OR "no system"]

Using the rules in this file (once a lead is generated it is a sales
problem, human reply within 5 minutes, the reply's 1 job is the
15-minute call):

1. Design my 5-minute response system around my real availability: alerts,
   who responds, and the honest backup plan for the hours I can't cover.
   Do not assume I can buy new software; use what I listed first.
2. Write 3 first-reply templates for a positive response, each under 40
   words, each with 1 job: land the 15-minute call. Match how a human
   texts, not how a company emails.
3. Write the 2 follow-up nudges for when a warm reply goes quiet, spaced
   over 2 days, no "just checking in."
4. Tell me where my handoff will most likely leak leads based on my
   answers, and the single cheapest fix.
5. If what I offer could plausibly demo itself through the way I follow up
   (like the story in this file), tell me how. If it can't, say so and
   skip the gimmick.
```

Always got your back,
RyMac
