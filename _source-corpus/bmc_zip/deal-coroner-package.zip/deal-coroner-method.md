# The Deal Coroner Method

Your deal did not die when they said "let me think about it." That line is the announcement, the way a flatline announces something that already happened. The deal died earlier, at a specific moment, and you probably talked right past it.

In the video, the call died at 23 seconds. That is when I quoted a price before asking a single diagnostic question. Everything after that, the polite questions, the "call me in a couple weeks," the "It's Chen" at minute 11, was a corpse being polite. I planted that mistake on purpose to test the coroner, and the coroner named it without being told: stage 2, the premature pitch.

Here is the frame that makes this work:

1. A sale is a state machine. You move through stages in order: rapport, diagnosis, commitment, presentation, test close, close. Each stage is a gate.
2. A gate is either PASSED, SKIPPED, or FAKED. Skipped means you never did it. Faked means you did the words but never got the real thing (asked questions but never found pain, got a "sounds good" but never got a commitment).
3. The deal dies at the FIRST skipped or faked gate. Everything downstream, the stall, the objection, the ghosting, is symptom, not cause.
4. An autopsy walks the transcript through the gates in order, finds that first bad gate, quotes the evidence, and rules the cause of death. It does not give you 12 tips. 1 cause, with receipts.

Why this beats "reviewing your calls": when you re-listen to your own call, you hear what you meant. The transcript read against a gate list shows what you did. My coroner handed me 4 separate chances Dr. Chen gave me to save that deal. I heard none of them live.

The full coroner is a free folder of plain text files: github.com/oathdriven/deal-autopsy. Drop it into a Claude project, paste your dead call as dead-deal.md, and say "run the autopsy." The pocket version is the prompt below, and it works in any AI with no setup.

## Run this prompt

```
You are a deal coroner. You do autopsies on dead sales deals. You do not give coaching, tips, or rewritten pitches. You find the cause of death.

Here is the frame: a sale moves through gates in this order: 1 rapport (they talk to you like a person), 2 diagnosis (you found the real pain and its cost BEFORE presenting anything), 3 commitment (they agreed the problem is worth solving now), 4 presentation (your offer, mapped to the diagnosed pain), 5 test close (you checked how they feel about moving forward), 6 close (you asked). Each gate is PASSED, SKIPPED, or FAKED (the words happened but the substance did not).

Walk my transcript below through the gates IN ORDER. Find the FIRST gate that was skipped or faked. That moment is the cause of death. Everything after it is symptom.

Rule the autopsy in this exact format:
CAUSE OF DEATH: [stage name + what happened in 1 sentence]
TIME OF DEATH: [the quote from the transcript where it happened]
THE GATE LEDGER: [each gate: PASSED / SKIPPED / FAKED + 1 line of evidence]
CHANCES I MISSED: [moments the prospect handed me a way back in, quoted]
CONFIDENCE: [high / medium / low + why]

Do not soften it. If the deal was dead before the stall, say exactly when.

TRANSCRIPT:
[paste your dead call transcript here]
```
