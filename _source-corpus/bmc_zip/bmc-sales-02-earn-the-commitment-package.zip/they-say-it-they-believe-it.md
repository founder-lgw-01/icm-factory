# They Say It, They Believe It

Yo! It's RyMac. Diagnosis is the examination. A doctor does not prescribe
before examining you. Neither do you. So examine.

## The questions

The same questions a doctor asks, translated to business:

- "What brought you in today?"
- "Does it hurt if I touch here?" becomes **"Are you happy with your
  results?"**
- "How long have you been in pain?" becomes **"How long have you had this
  problem?"**
- "What have you tried to get it fixed?"

Early questions dig for pain. 10 questions max, 15 minutes or under.
We're diagnosing, not interviewing. Past 15 minutes you're not a
doctor anymore, you're a survey.

## The one you never skip

**"Do you have a business partner or anyone else that should weigh in on
this call?"**

If every decision-maker isn't in the room, you'd be presenting to half a
brain. Ask it every time, even when you think you know the answer.

## The magic wand

The last question puts them in the future:

**"I just waved a magic wand. It is now July 14th, 2027."**

**"Where is your business, that would make you happy?"**

Pick a date about a year out from your call. And now something important
has happened: they have named their own pain and described their own
future. You didn't pitch anything. They built the case themselves.

## The law underneath all of it

**Never tell them anything you can get them to say themselves.**

They won't believe what you say. They will believe everything they say.
Every question in this stage exists to obey that one law.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [FILL IN]
Who buys it: [FILL IN]
The 3 pains my best customers had before they bought: [FILL IN]
The result they get after buying: [FILL IN]

Using this file (diagnose like a doctor; they say it, they believe it):

1. Build my 10-question diagnosis list. Order matters: early questions
   dig for pain, later questions size the problem, and the list must
   include the decision-maker question word for word: "Do you have a
   business partner or anyone else that should weigh in on this call?"
2. Every question must get THEM to say the pain or the future. If any
   question tells them something instead of asking, rewrite it.
3. End the list with the magic wand question, dated about a year from
   today, in this shape: "I just waved a magic wand. It is now [DATE].
   Where is your business, that would make you happy?"
4. Keep the whole list runnable in 15 minutes or under. If it runs
   long, cut questions, never depth on pain.
```

Always got your back,
RyMac
