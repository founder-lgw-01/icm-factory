# Change log

Every change to `_reference/`, `_templates/`, or `_system/` gets an entry. A
block change also names the builds re-run, because a block edit that does not
reach the builds is drift with a paper trail.

Newest first.

---

## 2026-09-07, packaged for release

This is the factory as it ships. The development record before this date was
the builder's working log and is not part of the package. Everything below is
what you hold.

- 5 stages, `00_intake` to `04_validate`, each a contract in `stages/`.
- 7 blocks in `_reference/blocks/`, the single home for text that appears in
  more than 1 built agent.
- The gate, `_system/validate.sh`, runs 11 labelled sections. The script header
  is the list. The last, `self-checks`, runs the checks a build ships on the
  files the factory wrote or repaired, so a source's own rules gate its build.
- `_system/test-gate.sh` proves the gate with 53 probes, planted defects that
  each block and legitimate look-alikes that each pass.
- Budgets, as variables at the top of `validate.sh`: `CLAUDE.md` 800 tokens and
  60 lines, root `CONTEXT.md` 800 tokens, each stage contract 650 tokens.
- Voice laws 1 to 5 are gated by `_system/voice-check.sh`. Law 3, digits, reads
  the files the factory writes; files copied from a source keep their author's
  numbers.
- `_source-corpus/` holds the ICM method (`ICM-architect/`, MIT-licensed). It is
  otherwise empty. A folder you want converted goes here, 1 per run.
- `runs/` and `builds/` are empty. The first run fills them.

Builds: none.
