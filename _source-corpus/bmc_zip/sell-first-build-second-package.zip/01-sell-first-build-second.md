# Sell First, Build Second

The whole video you just watched exists because of 1 rule: I do not build
anything until someone has paid me for it.

Last video, Dr. Chen paid $4,000 for an AI front desk that did not exist.
This video, I built what he paid for, in 1 sitting, on camera. That order is
the whole doctrine. Everybody teaches it backwards. They build something for
months, then go beg someone to buy it. I closed first, so the build had a
deadline, a spec, and a paycheck attached before I ever opened a folder.

## The 2012 story, short version

All I had in that market was a $9 PDF. My top affiliate, a guy I looked up
to named Chris Winters, called me at midnight: "You should sell them
something on the webinar tomorrow. Do you have something to sell?" I
panicked and said "yeah man, I do." I did not.

I had 12 hours. I sketched a $500, 5-week coaching program: show up 1 day a
week for 1 hour, I teach, I review your work. If nobody bought, I would
never have to build it. 100 people showed up. 40 bought. I watched my PayPal
fill up with $20,000 in 1 hour, and that moment turned into over $758,962.62
in about 10 months.

A $500 program that did not exist at midnight put $20,000 in my PayPal by
1pm. Last video, an AI receptionist that did not exist yet got me $4,000 on
camera. The same move, years apart.

## Why this works

1. Selling first is the only research that cannot lie to you. Surveys lie.
   Likes lie. A payment is the truth.
2. A closed deal turns "an idea" into a real project with a real deadline.
   You stop polishing and start shipping.
3. If nobody buys, you just saved yourself months of building the wrong
   thing. The no is a gift you got for free.
4. The pressure is the feature. I built Dr. Chen's entire front desk in 1
   sitting because a man paid me and was waiting.

## The trap this kills

"I'll sell it once it's ready" is the most expensive sentence in business.
Ready never comes, and the market moves while you polish. You do not have a
sales problem until you have something to sell, and the fastest way to have
something to sell is to sell it.

## Run this prompt

Paste this into your AI along with a description of what you do and what you
have been thinking about building:

```
I want to run a "sell first, build second" test this week. Here is my
situation: [describe your skills, your market, and the thing you have been
thinking about building].

Help me:
1. Turn my idea into 1 clear offer I could describe in 2 sentences on a
   phone call: who it is for, the pain it kills, and what they get.
2. Price it so I would be genuinely happy to deliver it if 1 person says
   yes, and it is a number they can say yes to on the first call.
3. Write the exact way I would offer it out loud, in my own words, no hype.
4. List 10 real people or businesses I could put this in front of within 7
   days, using what I already have (my phone, my email, my community).
5. Define what happens if someone says yes: what I deliver in week 1, so I
   am never selling something I cannot start.
Do not let me add features. Do not let me build anything yet. The test is
whether anyone pays, not whether it is impressive.
```
