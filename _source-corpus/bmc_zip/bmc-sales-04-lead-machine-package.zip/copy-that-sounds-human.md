# Copy That Sounds Human

Yo! It's RyMac. Infrastructure gets you into the inbox. The copy decides
what happens next. And the bar is brutally simple: it should look like a
human typed it, because a human should have.

## The format rules

- Plain text. No images. No links in the first email. No tracking pixels.
- Talk WITH the lead, not AT them.
- 1 specific pain, 1 honest question. That's the whole email.

That last line is the entire first email. Not your company story. Not your
feature list. 1 pain you know this exact niche has, and 1 honest question
about it.

## The ask is never "book a call"

It's a soft question. "Want me to send it over?" out-pulls a calendar link
almost 2 to 1. A calendar link asks a stranger for 30 minutes. A soft
question asks for a 1-word yes. Get the yes first. The call comes later,
and that part is a sales problem anyway.

## Banned forever

"Hope this finds you well." "I wanted to reach out."

The moment you sound like a template, you get deleted like a template.

## The follow-up is half the machine

Then you follow up. 4 or 5 more emails, spread over weeks. Every follow-up
is a NEW angle. Never "just checking in."

Here's the number that should change your behavior: 42%. That's how many
replies come from the follow-ups, not the opener. Quitting after 1 email
is leaving almost half the machine on the table.

New angle means new reason to reply: a different pain, a short result
story, a useful thing you're offering to send, an honest "should I close
your file?" at the end. If a follow-up could be summarized as "me again,"
delete it and write a real one.

## Run this prompt

Paste this into your AI with this file:

```
My business: [WHAT YOU OFFER AND THE RESULT IT GETS]
My list: [THE NICHE AND METRO FROM MY LIST SPEC, e.g. "roofers in Phoenix"]
The top 3 pains this niche complains about, in their words:
[PAIN 1] / [PAIN 2] / [PAIN 3]
What I can offer to send them free: [LEAD MAGNET, EXAMPLE, AUDIT, OR
"help me pick one"]
My name and how I naturally talk: [1 SENTENCE, e.g. "casual, blunt,
no corporate speak"]

Using the rules in this file (plain text, no images or links or pixels in
the opener, 1 specific pain plus 1 honest question, soft ask instead of
calendar link, every follow-up a new angle):

1. Write my opener: under 60 words, 1 pain, 1 honest question, ending
   in a soft ask like "Want me to send it over?". No greeting cliches.
2. Write 4 follow-ups spread over about 3 weeks, each a genuinely NEW
   angle, with a 1-line label naming the angle. The last one is the honest
   close-the-file email.
3. Audit all 5 against the banned list and the template test: flag any
   sentence a human wouldn't type to 1 specific person, and rewrite it.
4. Tell me which follow-up you predict wins and why, so I know what to
   watch when replies come in (remember: 42 percent of replies come from
   follow-ups).
```

Always got your back,
RyMac
