# Write Her on Paper First

The most important build step in the whole video happened in a text file,
not in any app. Before Ally had a phone, a voice, or a brain in the
platform, she was 1 page of plain English. That page is the product.

## The test the page has to pass

If a human could read this 1 page and play her on the phone convincingly,
the page is done. If a human would stumble, the AI will stumble the same
way. That is the whole quality bar, and it costs nothing to hit.

## What goes on the page (4 things, exactly)

1. **Who she is.** Her name, who she works for, and the manner she copies.
   Ally's line: super sweet, warm, empathetic, a sales person in medical
   clothing. Callers are already in pain, so booking is an easy close.
2. **Her call flow.** The framework compressed onto the call: Rapport lands
   the frame, then Diagnose, Get a Commitment, Present / Test Close, Close.
   The exact sentences, not descriptions of sentences.
3. **Her objection answers.** The 3 to 5 things callers actually push back
   with, and the exact words back, each ending in a return to booking.
   Ally's price answer never quotes a number: it pivots to the free
   consultation and goes right back to "what time works?"
4. **Her nevers.** Prices she cannot quote, promises she cannot make, topics
   she hands to a human. The nevers are what make her safe to leave alone
   with your customers.

## Why folders and plain English beat the whiz-bang

Everything she knows lives in files a 9th grader could read. When she missed
2 points on her first graded call, the fix was not a rebuild. I edited her
page, pasted it back in, and the next call carries the fix. Your AI employee
should be 1 readable page, because 1 readable page is 1 fixable page.

## Run this prompt

```
Help me write my AI front desk on paper first. My business: [what you do,
your hours, what gets booked, and the personality your shop should have on
the phone].

Write her 1-page brain with exactly 4 sections:
1. WHO SHE IS: name, personality, and her only job, in 3 sentences.
2. HER CALL FLOW: Rapport (warm open + a trust frame in my real numbers),
   Diagnose (3 exam questions), Get a Commitment (now or wait it out, in my
   words), Present / Test Close (a 1 to 10 question), Close (offer real
   times and book). Exact sentences she says, not summaries.
3. HER OBJECTION ANSWERS: my 3 most common pushbacks, exact words back,
   every answer ending in a return to booking.
4. HER NEVERS: what she may never quote, promise, or discuss, and the
   handoff line to a human.
The test: a human should be able to read this page once and play her on the
phone convincingly. If any line fails that test, rewrite it.
```
