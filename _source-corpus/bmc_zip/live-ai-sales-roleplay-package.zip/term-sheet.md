# Term Sheet

Every term from the video, in plain language, 1 line each.

- **Framework**: a system of stages you learn once that works on any call, forever. The opposite of a script.
- **Script**: "if they say this, you say that." Collapses the moment the prospect goes off the page.
- **The 6 stages**: Pre-call, Rapport Building, Get a Commitment, Present, Test Close, Close. In that order, every call.
- **Pre-call**: 15 minutes of homework on the prospect before you dial. Weave in 1 or 2 facts, never recite the file.
- **Rapport Building**: finding common ground and landing the frame, in 10 questions or fewer, 15 minutes or under.
- **The doctor frame**: "think of me as your business doctor." Once it lands, your questions become diagnosis instead of interrogation.
- **Landing the frame**: getting the prospect to agree to the doctor setup with a yes. It marks the end of rapport; everything after is diagnosing.
- **The magic wand question**: "if it's 1 year from today and you're thrilled, what happened?" Puts them in the future they want, in their own words.
- **Get a Commitment**: the stage almost nobody does. Locking in, before the pitch, that a yes at the end is on the table.
- **The commitment question**: "would you be opposed to moving forward if everything makes sense?" Deliberately asks for a no.
- **Asking for a no**: a no feels safe to say, a yes feels like pressure. The only time no means yes.
- **Present**: showing them you can get them where they want to be. Outcomes and math, never features.
- **Demo the tech**: showing off features and benefits. Creates questions, and weeds don't close deals. Don't do it.
- **The steak story**: the cook does not explain the recipe, you just enjoy the steak. Sell the meal, not the kitchen.
- **The roadmap**: the 5 to 7 steps a client walks with you, shown left to right, so the prospect can point at where they are.
- **The pin**: the step the prospect picks on your roadmap. The steps past it ARE the offer. Nobody argues with their own pin.
- **Profit calculator**: a simple sheet that takes the prospect's own numbers and shows what the problem costs them.
- **The hidden row**: the yearly total the calculator reveals last. $5,000 a week quietly becomes $250,000 a year.
- **2+2=4**: math is impossible to object. When they gave the inputs, the output is theirs, not yours.
- **Test Close**: temperature questions before any price is shown: "how does everything look so far?"
- **Close**: state the price, ask "what would you like to do next?", then silence. Mute yourself if you have to.
- **Objection**: a polite lie a prospect tells to avoid saying no to your face.
- **The polite lie**: "it's good, thank you for making it," said while chasing the casserole with a Pepsi. People lie to be nice.
- **The Spade**: handler 1. Calling out the lie respectfully, using the commitments from earlier in the call. Leads with "I'm confused."
- **Isolation**: handler 2. Getting every question on the table before answering any, so the objection loop can never start.
- **The objection loop**: objection, answer, new objection, repeat for 45 minutes. How you lose control of a call.
- **The 1-10 double tap**: handler 3. 2 questions back to back, ending in "on a scale of 1 to 10, where are you?"
- **The double tap**: asking the expected question, then immediately "actually, let me ask you this way," which reframes it.
- **The below-5 rule**: 5 and up means closeable. Below 5 is a polite "not even close." A random 3 gets the fun recovery line.
- **Order-taker**: what you become after "what would it take to get you to a 10?" They dictate their own closing conditions.
- **The 3 swings**: the closer's code. Take at least 3 swings, find the truth, never lie to them, never let them lie to you.
- **Self-diagnosis**: grading your own call after it ends, even the wins. Count the stages, catch the frames, name the handlers.
- **Sparring partner**: an AI prospect that objects, deflects, and hangs up, so you can practice without burning real leads.
- **Dr. Chen**: my hardest sparring agent. A booked-call prospect trained to fight every stage. If you can close David, you can close anyone.
- **A rep**: 1 full practice call against a sparring partner, graded after. The reps are the product.
