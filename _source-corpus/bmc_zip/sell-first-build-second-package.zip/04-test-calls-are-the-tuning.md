# Test Calls ARE the Tuning

Ally's first live call graded 9 of 11. I did not call that a failure, and I
did not call it done. I called it a grade, because you tune an AI employee
the exact way you coach a sales rep: real reps, a grade sheet, and film.

## The loop (this is the whole system)

1. Call her and play a real customer. Real pain, real objection, no script.
2. Grade the call against a written sheet, line by line, from the
   transcript. Not from your feelings about the call.
3. Anything she missed, fix her PAGE (the 1-page brain), not the vibes.
4. Call again. She is done when 1 clean call passes every line.

On camera her sheet had 11 points: opened warm, fresh sympathy before every
question, landed the trust frame, ran the Diagnose questions, asked for the
commitment, ran the 1 to 10 scale, closed with real calendar times, beat 1
objection, never quoted a price, booked a real slot, saved the caller as a
contact. She passed 9. She skipped the commitment question, and she said
"Great news!" right after I told her my pain was an 8. Both fixes became 2
new lines on her page the same night.

## Why a written sheet beats "it sounded good"

1. A grade sheet catches what your ear forgives. The call FELT perfect. The
   transcript showed 2 misses.
2. It separates your end from her end. My speakerphone garbled my name. The
   sheet showed her spell-back protocol CAUGHT the garble, so the stumble
   was mine, not hers.
3. It makes the fix cheap. Every miss maps to a sentence on her page. No
   miss, no edit. Miss, 1 edit.
4. It gives you a finish line: 1 clean call that passes every line. Without
   the sheet, tuning never ends and you tinker forever.

## Run this prompt

```
Help me build a grade sheet for [the thing I am building: an AI front desk,
an AI chat agent, a sales script, a landing page, anything a customer
touches].

1. Write a 10 to 12 point pass/fail sheet where every line is 1 observable
   behavior: something I can verify from a transcript or recording, never a
   feeling. Include at least 1 line for each: the opening, the questions it
   must ask in order, the 1 objection it must beat and return from, the
   things it must NEVER say, and the real end result (a booking, an order, a
   saved contact) that proves the loop closed end to end.
2. Then define the test: the character I play, the pain I present, and the
   exact objection I throw.
3. Then define done: how many consecutive clean passes it needs before it
   goes in front of a real customer.
After my first test, I will paste the transcript. Grade it against the
sheet, mark each line pass or fail with the quote that proves it, and give
me the exact edits to my instructions that fix each miss. Fix the page, not
the vibes.
```
