# Every Inbound Call Is a Sales Call

The front desk is the most important sales seat in the building, and nobody
treats it that way. In the video, I built Dr. Chen's AI front desk to run my
sales framework on every single call, because a patient calling a
chiropractor is not "an inquiry." It is a sales call where the hard part,
the pain, already happened.

## The framework, compressed onto 1 phone call

My full framework runs Pre-call, Rapport, Diagnose, Get a Commitment,
Present, Test Close, Close. On an inbound call, pre-call is done the moment
the phone rings (they called YOU), so she runs the rest, in order, every
call:

1. **Rapport lands the frame.** Warm open in the practice's voice. She hears
   the pain, answers with real sympathy, then lands the trust frame: "You've
   called the right place. Dr. Chen has helped 1,000s of patients over the
   last 10+ years." That line does 1 job: it makes her the doctor's office,
   not a stranger. The frame is landed.
2. **Diagnose.** The moment the doctor frame lands, she IS a doctor, and
   doctors diagnose: "Tell me more about your pain." "When did it start?"
   "What have you tried?" She is not making small talk. She is running the
   exam that earns the close.
3. **Get a Commitment.** "Are you looking to see a doctor right now, or do
   you want to wait the pain out and see if it gets better?" This is the
   hinge of the whole call. They say out loud that they want help NOW.
4. **Present / Test Close.** "On a scale of 1 to 10, where's the pain right
   now?" A high number is them presenting the case to themselves.
5. **Close.** "Oh no, that's awful. Let's get you in ASAP." She checks the
   real calendar, offers real times, and books it. The close IS the
   scheduling.

On her first live call she beat my price objection with this flow and booked
a real appointment in 4 minutes 16 seconds. Nothing clever. Just the stages,
in order, without skipping.

## The reframe

Scheduling an appointment is a sales activity. Your front desk, human or AI,
was never hired to sell, and that is exactly why calls leak. You do not need
a closer at the front desk. You need the framework compressed onto the call,
so the call closes itself.

## Run this prompt

Paste this into your AI with a description of your business:

```
My business: [what you do, who calls you, and what a booked
appointment/job/order is worth].

Compress this sales framework onto MY inbound calls: Rapport (land a trust
frame in my business's voice), Diagnose (the 3 exam questions that surface
the caller's real pain), Get a Commitment ("do you want this handled now, or
do you want to wait it out?" in my words), Present / Test Close (a 1 to 10
question that makes the caller present the case to themselves), Close (the
booking or next step, offered immediately with real options).

Give me:
1. The exact call flow, stage by stage, in words that sound like my shop.
2. My trust frame sentence, using my real numbers (years, customers,
   reviews). If I gave no numbers, ask me for them, do not invent any.
3. The 3 diagnose questions for my specific business.
4. Answers for my 2 most common objections that always return to booking.
5. The nevers: what the person answering may never promise or quote.
Keep every line short enough to say out loud naturally.
```
