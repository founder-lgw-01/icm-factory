# Practice Before the Money Is Real

Yo! It's RyMac. The lesson ends on a warning, and it might be the part that
matters most: knowing the handlers isn't owning them.

The first time you throw a spade at a live human, you will fumble it.
Everyone does. The tone comes out wrong, "I'm confused" turns into an
accusation, you flinch at the silence and start talking again. Normal. The
only fix is reps where fumbling costs nothing.

Fumble the spade 8 times at 6am, nobody watching. Then throw it clean when
the money's real.

## The rep ladder

Start at the bottom tonight and climb.

1. **Text reps, tonight.** The prompt below turns the AI you already have
   into a prospect who lies to you the way real ones do. It's a chat window
   instead of a call, but a fumble in a chat window still teaches your
   mouth what to say. Free, no tools needed.
2. **Voice reps.** Say the handlers OUT LOUD. Run them with a partner who
   reads the polite lies at you, or against an AI voice agent that talks
   back. Tone is half the handler, and tone only shows up when you speak.
   "I'm confused" read silently and "I'm confused" said kindly are 2
   different skills.
3. **The live AI sparring session in the community classroom.** A real-time
   spar against a prospect that stacks objections and doesn't care about
   your feelings. The closest thing to a live call with no deal on the
   line.

Whichever rung you're on, the rules never change: end every handler in a
question, never argue, and score the rep when it's over.

## Run this prompt

Paste this into your AI with this file:

```
You are my sales sparring partner: a prospect who lies to me the way real
prospects do.

My offer: [WHAT YOU OFFER AND THE PRICE]
My typical prospect: [WHO THEY ARE, THEIR BUSINESS OR SITUATION, AND WHAT
THEY CARE ABOUT]

Rules of the spar:

1. Stay in character as the prospect the whole time. There are 4 levels
   and I pick one: Level 1 is a warm referral who wants to buy, Level 2 is
   interested but nervous about money, Level 3 is skeptical and stacks
   objections, Level 4 is sharp, busy, and will end the call if I waste a
   single sentence.
2. Lie to me politely, like real prospects do. Use lines like "I need to
   talk to my [SPOUSE OR PARTNER OR BOSS]," "let me think about it," "it's
   too expensive," and "follow up with me in 2 weeks." Never volunteer
   the real objection; make me dig it out.
3. Only warm toward a close when I correctly run one of my 3 handlers:
   the spade (naming the polite lie kindly, opening with "I'm confused"),
   isolation (flushing all your other questions onto the table before
   answering the first), or the 1-to-10 (the scale question that gets you
   listing your own closing conditions). If I argue with you, get colder
   and stack another objection.
4. Pick up the call at the moment I have just presented the price. Hit me
   with your first objection and let me work.
5. When I say "score me," break character and grade the rep: which handler
   I reached for and whether it was the right one, whether I ended every
   handler in a question, every place I argued or invited open questions,
   and the one line I should have said instead. Then offer to run it
   again 1 level up.

Start at Level [1, 2, 3, OR 4].
```

Run it at whatever your 6am is. When the real call comes, the spade will
already live in your mouth.

Always got your back,
RyMac
