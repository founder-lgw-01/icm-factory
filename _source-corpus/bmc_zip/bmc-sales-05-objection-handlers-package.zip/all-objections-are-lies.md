# All Objections Are Lies

Yo! It's RyMac. Before you learn a single handler, you have to believe the
diagnosis, because every handler in this package is built on it.

## The truth nobody says out loud

All objections are lies.

Not evil lies. Polite ones. People lie to be nice. It's almost always about
the price, and they don't want to hurt your feelings. "I need to talk to my
wife." "Let me think about it." "Follow up with me in 2 weeks." Different
costumes, same lie underneath.

Your job isn't to argue. Your job is to get to the truth, kindly.

## Why 3 handlers, not a binder

The guru move is to pitch you a binder of rebuttals: 1,000 "if they say
this, you say that" flashcards. That crap collapses on a live call. Nobody
flips through a binder mid-sentence with a real human on the line.

You need exactly 3 handlers. The spade. Isolation. The 1-to-10.

You can't spade everything. You can't isolate everything. You can't 1-10
everything. But with all 3? Any objection on earth. And you can mix them.

## The 3 control rules under every handler

1. Never invite open questions. "Got any questions?" is asking to get
   hammered.
2. Relate them to a best customer, then take the mic back. "Our best
   customers asked the same thing before they got started."
3. Never argue. Nobody buys from someone they're arguing with.

And the rule that binds all 3: every handler ends in a question. Then you
close again.

## The real secret: the framework pre-kills most objections

Objections at the close are unpaid debts from stages you skipped.

Run every stage clean, from Lurk through Rapport, Diagnosis, the
Commitment, Present, and the Test Close, all the way to the Close, and most
objections never show up at all. The handlers are your emergency kit, not
your toolbox. If the same objection hits you on every single call, the fix
usually isn't a better handler. It's the stage you keep skipping. Sales is
a framework, not a script.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT YOU OFFER AND WHO BUYS IT]

My call usually goes: [THE ROUGH SHAPE OF YOUR CALL: how it opens, whether
you ask for any commitment up front, how you present price, how you ask
for the close]

The 3 objections I hear most, in the prospect's exact words:
1. [OBJECTION 1]
2. [OBJECTION 2]
3. [OBJECTION 3]

Using this file:

1. For each objection, tell me what the polite lie is probably covering
   (price, trust, no real pain, no authority to buy) and why you think so.
2. Diagnose the stage debt: which stage of the framework (Lurk, Rapport,
   Diagnosis, the Commitment, Present, the Test Close, the Close) did I
   likely skip or rush, and how did that let this objection survive to the
   end of the call? Ask me questions if you need more detail before you
   diagnose.
3. Assign the right handler to each objection (the spade, isolation, or
   the 1-to-10) and explain why that one and not the other 2.
4. Check my call shape against the 3 control rules and flag every place I
   invite open questions, skip the best-customer relate, or argue.
```

The full framework the stages come from is free at buildmarketclose.com.

Always got your back,
RyMac
