# Term Sheet

Every term from the video, in plain language. No question in the community
is too basic; this file exists so you never have to ask "wait, what's the
spade?"

**Stage** · Where the call is right now. You are always in exactly one, and you never skip one.

**The Lurk** · 15 minutes of quiet recon before you dial: their LinkedIn, their website, what they post, how they talk, what they're proud of. Distilled to 1 page.

**Recon** · The research itself. Gathered quietly, never announced.

**Weave, never recite** · Use what the Lurk found naturally in conversation. Never say "I did my homework on you," never read their file back to them.

**The name rule** · The most important word in the English language is someone's name. Say it once in the first 30 seconds, naturally.

**Rapport** · 1 or 2 minutes of real common ground. No weather talk.

**Common ground** · A genuine overlap between you and them (their city, your service time, their team). The Lurk tells you where it lives before they answer.

**Help statement** · The fill-in-the-blank intro: "I help [who] [get the outcome] using my [whiz-bang] so they can [what they'd rather be doing]." Always followed by a question.

**Whiz-bang** · Your named system or method. The thing only you have that makes the help statement yours.

**The Business Doctor frame** · The permission line: think of me as your business doctor, I'll ask questions to diagnose and prescribe, and if I can't help I'll refer you to a specialist. It has to end in a yes, and it licenses every question after it.

**End in a question** · The rule for every line you say: a statement sits there, a question makes them answer, and their answer moves the call forward.

**Diagnosis** · The examination. Doctor questions translated to business. 10 questions max, 15 minutes or under. Diagnosing, not interviewing.

**Pain** · The problem in THEIR words. Early diagnosis questions exist to dig it out.

**The decision-maker question** · "Do you have a business partner or anyone else that should weigh in on this call?" Never skipped.

**Half a brain** · What you're pitching to when a decision-maker is missing from the room.

**The magic wand** · The future question: "I just waved a magic wand. It is now [a date about a year out]. Where is your business, that would make you happy?" Gets them to describe their own happy future out loud.

**The Commitment** · Their conditional agreement to move forward, earned BEFORE you present anything. The stage everyone skips.

**"Would you be opposed"** · The shape of the commitment question. A no feels safe to say, and here a no means yes.

**The spade** · Their own commitment words, in your pocket. Every objection that shows up later has to argue with their words, not yours.

**The walk-away** · Ending the call politely when there is no commitment. Thank them for the honesty, hand them a fair next step, get off the phone.

**No commit, no presentation** · The rule the walk-away enforces. A deal that skips the Commitment dies at the pitch.

**Present (the presentation)** · Showing them how you get them to the goal. Only happens after the Commitment. Next lesson, along with the Test Close and the Close.

**Insurance** · Why you skip nothing: every stage is insurance for a later stage.
