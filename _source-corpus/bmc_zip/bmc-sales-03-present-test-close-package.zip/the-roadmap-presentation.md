# The Roadmap Presentation

Yo! It's RyMac. You lurked. You built rapport. You diagnosed. And you got
the commitment; they said it out loud: "No, I wouldn't be opposed if
everything makes sense." Their word is in your pocket. Now comes the
Present stage, and this is the exact moment every builder blows it.

## The rule that hurts nerds the most

**Never demo the tech.**

I know. You built the whiz-bang. It's beautiful. You want to show all
17 features. Never get into the weeds of the whiz-bang's features.
Weeds don't close deals.

3 minutes inside the product, tops. Prove it exists. Get out.

Because features make them think. And thinking out loud sounds like "let
me think about it."

## Present a roadmap instead

The full journey from their pain to their happy future, in numbered steps.
Mine was 9 steps in 3 phases. 1 page. No dashboard.

Then the magic move: have them locate themselves on it. The lines, word
for word:

"This is the steps needed to fix your problems. Everyone falls at a
different place."

"Which step are you currently on?"

They look. They point. "Probably step 4."

"Great news, most people are much further behind. You're on step 4."

"I handle steps 5 through 9 while you focus on [what they'd rather be
doing]."

Being at step 4 is GREAT news. Say it out loud. Ally energy, progress
not deficiency.

And notice what just happened: they placed their own pin on the map.
**Nobody argues with their own pin.**

The steps they haven't reached yet? That IS the offer.

## The receipt

I closed a $30,000 Airbnb program with exactly this move. The offer
owner was doing long, drawn-out demos, and deals were dying everywhere.
I showed a roadmap. 9 steps, 3 phases. Had them find themselves on it.
"You're on step 4 because you've already done 1, 2, and 3, because your
credit's about 700. So it's great news."

71%. That was my close rate. On a $30,000 offer. With a roadmap.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT IT IS, WHO IT IS FOR, AND WHAT IT COSTS]

The pain my buyer starts with: [THE PROBLEM IN THEIR OWN WORDS]

The happy future my offer delivers: [THE END RESULT, WITH A REAL NUMBER
IF YOU HAVE ONE]

What my buyer would rather be doing than this work: [FILL IN]

Using the method in this file:

1. Map the full journey from that pain to that happy future in 7 to 10
   numbered steps, grouped into 2 or 3 named phases. Plain words a 5th
   grader could read. It must fit on 1 page. No product features, no
   screenshots, no dashboard.
2. Mark which steps a typical buyer has usually already done before they
   ever talk to me, so that wherever they point, I can honestly call it
   great news.
3. Write my pin script word for word: the "everyone falls at a different
   place" setup, the "which step are you currently on?" question, the
   great-news response, and my version of "I handle steps X through Y
   while you focus on [what they'd rather be doing]."
4. Check the finished roadmap against the rule: if any step describes my
   product instead of their journey, rewrite it. The steps they haven't
   reached yet should read as the offer without me ever pitching.
```

Always got your back,
RyMac
