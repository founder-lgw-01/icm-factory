# Term Sheet: the Deal Autopsy video

Every term of art from the video, 1 line each, plain language.

- **Deal coroner / deal autopsy**: an AI that reads a dead sales call transcript and names the stage where the deal actually died, with evidence.
- **Cause of death vs the announcement**: the cause is the first skipped step early in the call; the announcement is the stall you heard later ("let me think about it"). They are almost never the same moment.
- **State machine**: the idea that a sale moves through fixed stages in order, and you cannot skip one without paying for it later.
- **Gate**: a stage treated as a checkpoint: you either PASSED it, SKIPPED it, or FAKED it.
- **Faked gate**: you said the words but never got the substance (asked questions but found no real pain, heard "sounds good" but got no commitment).
- **Stage 2 / diagnosis**: the stage where you find the prospect's real problem and what it costs them, BEFORE you present anything.
- **Premature pitch**: presenting price or product before diagnosis. The planted mistake in the video's call 1, dead at 23 seconds.
- **Planted mistake**: 1 known error deliberately placed in a test call so you can check whether the AI finds it blind.
- **Murder test**: validating an AI on cases where you already know the answer before trusting it on cases where you do not.
- **Ground truth**: the known right answer a test is scored against.
- **Blind test**: the AI gets the transcript and nothing else. No hints about what was planted.
- **The 1-10 handler**: the objection handler: agree with the stall, ask where they are on a scale of 1-10, then ask what would take them to a 10.
- **AI sparring partner**: an AI prospect (Dr. David Chen in the video) that calls your real phone and fights back, so you can practice and run tests.
- **ICM (interpretable context methodology)**: Jake Van Clief's folder system: an AI built as a folder of plain text files, each doing 1 job, that you can read and audit.
- **The ruling / verdict**: the coroner's output: cause of death, the quoted moment, the gate ledger, and a confidence rating.
- **Confidence rating**: the coroner saying how sure it is, so a shaky ruling cannot hide behind confident language.
