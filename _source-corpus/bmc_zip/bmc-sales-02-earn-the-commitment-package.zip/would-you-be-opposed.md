# Would You Be Opposed

Yo! It's RyMac. The Commitment is the stage everyone skips. The name on
the door. You've done the Lurk, landed the doctor frame, and they've named
their own pain and described their own future. One move left before you
ever show them anything.

## The line, word for word

**"So Claude, great news, I can help you get to that goal."**

**"Before I show you how, I wanted to know: if everything makes sense to
you... would you be opposed to moving forward at the end of this call?"**

Read it again. I did not ask for a yes.

## The only time "no" means "yes"

Ask "are you ready to move forward?" and their survival instinct spikes.
Alarm bells. Why is this stranger asking me to commit already?

But "would you be opposed?" A no is safe to say. So they say it: "No, I
wouldn't be opposed if everything makes sense."

Boom. That's a spade in your pocket. Every objection that shows up later
now has to argue with their own words, not yours.

## When the truth walks out instead

Sometimes the honest answer shows up right here. Let it. Real call:

"Honestly, I'm in the middle of moving, I couldn't do anything until next
month anyways."

That is not a commitment. Do not move on. Here's what I said, word for
word:

**"Thank you for being honest here. Most people would just lie to me and
we'd be wasting both of our time."**

**"A lot could change between now and then. You have my email, why don't
you reach back out when you're settled in and ready. Does that sound
fair?"**

I was off that call in 10 minutes instead of 45. She never reached back
out. Exactly as predicted.

**No commit, no presentation. Time saved is money made.**

A deal that skips the Commitment dies at the pitch. Skip nothing: every
stage is insurance for a later stage, and this one insures all of them.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [FILL IN]
What my prospect usually says their goal is by this point in the call:
[FILL IN]
The excuse I hear most when someone won't commit: [FILL IN, e.g. "need to
think about it," "bad timing," "have to ask my partner"]

Using this file (the commitment question + the walk-away):

1. Write my commitment ask using the exact shape from this file. Keep the
   load-bearing words: "great news," "if everything makes sense to you,"
   and "would you be opposed to moving forward at the end of this call?"
   Only swap in the prospect's name and their stated goal.
2. Write my walk-away script for the excuse above, in the same 2 beats as
   mine: thank them for the honesty, then hand them a fair next step that
   ends in a question.
3. Now drill me. Play my prospect 3 times: once committing cleanly, once
   giving my common excuse, once giving a vague stall. After each of my
   replies, grade me: Did I ask for a "no" instead of a yes? Did I move
   forward without a commitment? Did I let the truth walk out when it
   showed up?
```

More free lessons are coming at buildmarketclose.com.

Always got your back,
RyMac
