# The Line Between A Salesman And A Closer

Yo! It's RyMac. There is a difference between a sales person and a sales
closer, and it is not talent, charisma, or how many rebuttals you memorized.

## The line

**Being a sales closer means you don't lie to your prospects and you don't let
them lie to you.**

**A salesman lets their prospects lie to them. Sales closers don't.**

That is the hat. It is not a personality and it is not a voice you put on. It
is a standard you hold on both sides of the call.

## Why the second half is the hard half

Everybody nods at "don't lie to your prospects." Fine. Nobody is arguing for
lying.

The part that actually separates people is refusing to let THEM lie to YOU.

They will. Not because they are bad people, but on reflex. "Let me think about
it." "Send me some info." "I need to talk to my partner." Most of the time none
of that is true. It is a polite exit, and the salesman takes it, says thanks,
and puts a dead deal on his board that he will chase for 2 weeks.

The closer does not take it. Not by being aggressive. By asking for the real
answer, and being fine with it if the real answer is no.

## What it costs you to skip it

Every lie you accept becomes a follow-up you will never get answered, a number
on your board that is not real, and a forecast you cannot trust. You do not
have a list of live deals. You have a list of people who were too polite to
tell you no.

That is the actual cost. Not the deal you lost, the 2 weeks you spent believing
you had it.

## Run this prompt

```
You are auditing my last 10 sales conversations for accepted lies.

For each one I will give you: what they said at the end, what I said back, and
what happened after.

[paste your 10, one per line. If you do not track this, use the last 5 you
remember, and note that gap.]

Do this:

1. For each conversation, tell me whether the ending was a REAL answer (a yes
   or a clean no) or an AMBIGUOUS one ("think about it", "send info", "call me
   in 2 weeks", "talk to my partner"). Count them.

2. For every ambiguous one, write the question I could have asked to get the
   real answer, in plain language, that would not have made me sound
   aggressive.

3. Tell me how many days I spent following up on the ambiguous ones, based on
   what I told you, and what that time was worth at my average deal size.

4. Give me 1 sentence I can use at the end of every call from now on that
   makes it easy for somebody to tell me no.

Rule: never suggest I push harder. The goal is a REAL answer, not a yes.
```
