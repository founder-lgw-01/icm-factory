# Small Perfect Lists

Yo! It's RyMac. The list is where most people lose before they ever send.
Let me teach you the hard way first, because I lived it.

## The hard way (so you don't have to)

My old setup: Apollo to scrape the leads. TrustedLeads to enrich them.
MillionVerifier to clean them. Then load everything into Instantly and pray
the handoffs don't drop anybody. 4 tools. 4 bills. And up to a WEEK from
starting to leads going out. It worked. It also taught me every mistake, so
you don't have to make them.

The fast way collapses the first 3 tools into one dashboard (Consulti is
the one I run, and yes, I'm an affiliate, said the same thing on camera).
That week became same-day: build the list in the morning, load the campaign
by the afternoon. It even builds lead magnets. I practice what I preach:
the analyzer sitting on allodra.ai is one of those lead magnets, live right
now, and it goes straight into my own cold emails. But hear this part
clearly: tool or no tool, the discipline below is the whole game, and every
bit of it works with free scraping and cheap verification if that's where
you are.

## The discipline (this never changes)

**Scrape 1 niche in 1 metro at a time.** Tight beats big. "Roofers in
Phoenix" is a list. "Home services in America" is a landfill.

**Verify every email before it sends.** Over 3 percent bounces? Hard stop.
Do not send. Bounces tell the inbox providers you're a spammer, and that
poisons the domains you just spent weeks warming up.

**Small and perfect beats big and maybe.** A list of 200 perfect fits
out-pulls a list of 5,000 maybes. Nearly double the reply rate. Every bad
fit on your list costs you twice: once as a send that can't convert, and
again as damage to your sender reputation.

## Run this prompt

Paste this into your AI with this file:

```
My business: [WHAT YOU OFFER, THE RESULT IT GETS, AND YOUR PRICE RANGE]
My best current customer: [DESCRIBE 1 REAL CUSTOMER: INDUSTRY, SIZE,
LOCATION, WHY THEY BOUGHT]
Where I can hunt: [METROS OR REGIONS YOU CAN CREDIBLY SERVE]
My list tools right now: [WHAT YOU HAVE, OR "nothing yet"]

Using the rules in this file (1 niche in 1 metro, verify everything,
3 percent bounce hard stop, 200 perfect fits over 5,000 maybes):

1. Propose 3 candidate niche-plus-metro combos for my first list, ranked,
   with 1 line on why each fits my best-customer profile.
2. For the top pick, write my list spec: who qualifies (industry, company
   size, role or owner title, any signals that predict they need me) and
   who is disqualified even if they look close.
3. Set my target list size (aim near 200 perfect fits) and tell me what to
   cut first if my scrape comes back bigger.
4. Give me the verification gate as a checklist: verify every address,
   compute the projected bounce rate, and the hard rule for what happens
   at 3 percent.
5. Suggest 1 simple lead magnet I could offer this exact list, something I
   can build free with an AI, and the 1-line description of it I'd use in
   an email.
```

Always got your back,
RyMac
