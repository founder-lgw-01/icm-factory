# The 1-10 Handler

"Let me think about it" is not an objection. It is a curtain. The 1-10 handler is how you open the curtain without being pushy, and on a normal call it is the first thing I reach for when I hear a stall.

Here is the exact exchange from the video, word for word:

Them: "Let me think about it."

Me: "Understandable, it's a big decision. While you got me on the phone, what are you thinking about? Actually, let me ask you this. On a scale of 1-10, 1 being I wish I never showed up to this call, and 10 being I'M READY RIGHT NOW, where are you?"

Them: "7."

Me: "Great, what would it take to get you to a 10?"

And then they tell me how to close them.

Why it works:

1. "Understandable, it's a big decision" agrees with them. You cannot fight a stall head on; agreeing drops their guard.
2. The 1-10 question is impossible to answer with a curtain. A number is a diagnosis. A 7 means something specific: interested, not convinced.
3. "What would it take to get you to a 10" makes THEM name the gap. Whatever they say next is the real objection, and now you are handling that instead of shadowboxing "let me think about it."
4. If they say 2, you also win. You just saved yourself 2 weeks of chasing a corpse.

In the video I did NOT run this handler on purpose, that was the planted mistake on the call you heard, and the coroner flagged the deal as dead anyway, earlier, at the skipped diagnosis. Which is the real lesson: the handler saves deals that died at the close. Nothing saves a deal that died at 23 seconds. Run the autopsy first, then drill the handler.

## Run this prompt

```
I sell [describe your offer and who buys it in 1-2 sentences].

Step 1: Adapt this objection handler to my offer, keeping its exact structure: agree with the stall, then ask "on a scale of 1-10, 1 being I wish I never showed up to this call and 10 being I'm ready right now, where are you?", then whatever number they give, ask "what would it take to get you to a 10?" Write my version in natural words I would actually say on a call.

Step 2: Now roleplay as my prospect. Give me a stall ("let me think about it", "send me some info", "I need to talk to my partner", "the timing isn't right", "it's too expensive"), 1 at a time, 5 rounds. After each of my replies, tell me honestly: did I agree first, did I get a number, did I get them to name the gap? Score me 1-10 per round and tell me the 1 thing to fix before the next one.

Start round 1 now.
```
