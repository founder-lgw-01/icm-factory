# Own the Wiring: 9 Cents a Minute

The 16 minute call where I closed Dr. Chen for $4,000 cost me $1.42. About 9
cents a minute, because I own the wiring. Ally's first live call, a full
4 minute close with a booked appointment, cost 26 cents. Those are real
receipts from real bills, and they are the quiet superpower under this whole
business.

## The rent is the margin

Run those same minutes through the middle-man platforms and you pay $0.50 to
$1.00 a minute for the same call. That is 5 to 10 times the cost, forever,
for the privilege of renting what you could own. When you own the wiring:

1. Your delivery cost is so low that almost every dollar you charge is
   yours to keep.
2. You can promise clients real usage without sweating a bill you cannot
   predict.
3. Nobody can raise your rent, change your terms, or sunset the tool your
   business stands on.

## The floor: never price blind

My rule: at least 65% of every dollar stays with me after delivery costs.
The math takes 1 minute:

1. Estimate the minutes (or units) a client will actually use per month.
2. Multiply by your true cost per minute. Mine measures at about 9 cents,
   and I plan with 10 to be safe.
3. Price so at least 65% of the fee survives that cost. If it cannot, the
   offer is broken BEFORE you sell it, and no amount of closing skill fixes
   broken math.

Dr. Chen's front desk will talk for pennies a day and books appointments
worth hundreds each. That gap is the business.

## Run this prompt

```
Run my owned-versus-rented delivery math. The thing I deliver (or want to
deliver): [describe it: AI calls, AI chat, software, a service].

1. List every real cost per unit of delivery (per minute, per conversation,
   per job). If I do not know a number, tell me exactly how to measure it
   from a real bill instead of guessing.
2. Show my delivery cost at 3 usage levels: light, normal, heavy month.
3. Apply the 65% floor: at each usage level, what is the LOWEST price I can
   charge where 65% of the fee still stays with me?
4. Now show the same math if I delivered through a rented middle-man
   platform at typical marked-up rates, and show what the rent costs me per
   year at normal usage.
5. Give me the 1-sentence version of this math I could say out loud on a
   sales call to justify my price with a straight face.
```
