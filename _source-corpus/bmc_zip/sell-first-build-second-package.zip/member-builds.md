# Member Builds: the room record

This file is the record of what THIS room built with the sell-first-build-
second drop. Build your own front desk (or run any prompt in this package on
your own business), post it in the community, and you go in this file with
your name on it.

What earns a block here:

- You wrote your front desk on paper (file 03) and posted her page
- You ran a test call and posted your grade sheet results (file 04)
- You ran the sell-first offer test (file 01) and posted what happened,
  including the nos
- You ran your owned-vs-rented math (file 05) and posted your floor price
- You compressed the framework onto your inbound calls (file 02) and posted
  the flow

Imperfect beats polished. A 6 of 11 grade posted honestly teaches the room
more than a highlight reel.

---

*No builds recorded yet. This drop just landed. First one in gets the top
block forever.*
