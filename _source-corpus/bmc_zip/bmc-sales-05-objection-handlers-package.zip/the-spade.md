# The Spade

Yo! It's RyMac. Handler 1 of 3. The spade is for the polite lie itself:
when you know the objection is a no wearing a costume, and you name it,
kindly, and ask about it.

## Where it came from

The spade was born on a real call, not in a course. I told a prospect:

"Let's call a spade a spade, you just lied to me because you didn't want to
hurt my feelings."

"You know when I call you in 2 weeks you won't answer. Right?"

He knew. I knew. And I thought: oh shit, I'm tucking that spade away.

## The polished version

It always leads with the same 2 words: "I'm confused."

Confusion is authentic. "Hold up" is confrontational. So when they say "I
need to talk to my wife first," you say:

"I'm confused. At the start of the call you said you would not be opposed
if everything makes sense, and you said it made sense."

"Normally when people say that, they're really telling me no and don't want
to hurt my feelings. Is that what just happened here?"

Notice what that leans on: the commitment you locked in back in the
Commitment stage. No commitment, no spade. That's why you never skip it.

## When they double down

Sometimes they insist: "No no, I want to, I just have to talk to her." You
have 3 moves.

**The deposit.** "Cool, go ahead and hold this price with a deposit, speak
with her and we can settle the rest after." "If she tells you no, I'll just
refund your money back." A refusal there tells you everything.

**The surgical question.** "Why do you think SHE would say no?" Whatever
they answer is the real objection. The wife was never the objection. Handle
that, and close.

**The big-boy line.** "I'm a big boy, you can just tell me no." You earn
respect and close, or earn respect and maybe a friend. Either way, you
don't get pushed over and lied to.

## The 2-weeks spade

The same spade kills "follow up with me in 2 weeks":

"I've been doing this a long time. Every time someone says follow up in 2
weeks, and I do... what would your guess be with how many people respond?"

They mumble "I don't know." So you tell them: zero. No one ever responds.

"Telling me to follow up in 2 weeks was just you telling me no, but you
didn't want to hurt my feelings. Is that the case?"

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT YOU OFFER AND WHO BUYS IT]

The commitment I ask for early in the call: [THE EXACT WORDS YOU USE TO
GET AGREEMENT UP FRONT, OR "I don't ask for one"]

The polite lie I hear most, in the prospect's exact words: [THE OBJECTION]

How I actually talk: [2 OR 3 SENTENCES THE WAY YOU'D SAY THEM ON A CALL,
SO THE SCRIPTS SOUND LIKE ME]

Using this file:

1. If I don't ask for a commitment, write mine first. No commitment, no
   spade, so this comes before everything else.
2. Write my spade word for word: open with "I'm confused," reference my
   actual commitment, and name the polite lie kindly. Keep it in my voice.
3. Write my double-down set: a deposit-style counter that fits [WHAT A
   REFUNDABLE DEPOSIT OR SMALL FIRST STEP LOOKS LIKE FOR MY OFFER], the
   surgical question adapted to whoever my prospects hide behind, and my
   version of the big-boy line.
4. End every script in a question, and flag anywhere I might sound like
   I'm attacking instead of confused. The spade names the lie kindly or it
   isn't a spade.
```

Always got your back,
RyMac
