# Math Is Impossible to Object

This file is the Present stage, the part where most people blow the deal by showing off.

## Never demo the tech

Do not show off features and benefits. They overwhelm the prospect and create more questions, and questions make your path to the close harder. Weeds don't close deals.

Think of it this way. The last time you had a fantastic meal at a restaurant, did the cook come out and break down the entire recipe? How long it took, the tablespoon of this and that? Or did you just enjoy the steak?

Your prospect wants the steak. The outcome. Not the recipe.

## The roadmap and the pin

Show them a roadmap of the steps a client goes through with you, laid out left to right. Then ask 1 question: "Which step are you on?"

Whatever step they pick, the steps they have not reached ARE the offer. You did not tell them they need you. They pointed at a spot on a map and told themselves. Nobody argues with their own pin.

## The profit calculator

Show them a profit calculator. Have them enter THEIR numbers, not yours. Let it calculate their ROI based on what they said.

In the live call, the numbers were the prospect's own: 10 missed calls a week, $1,000 per patient, 50% close rate. That is $5,000 a week walking out the door, and the hidden row underneath is $250,000 a year. He gave me every input. I just did the arithmetic out loud.

That is the whole trick: never tell them anything you can get them to say themselves. Their numbers, their leak, their conclusion.

## 2+2=4

Math is impossible to object. 2+2=4. On any day that ends in Y.

When the prospect supplies the inputs, the output is not your claim to push back on. It is their own math staring at them. The close stops being persuasion and starts being arithmetic.

## Run this prompt

Paste this file into your AI, add your details, and run it:

```
You are my sales-presentation designer. Above is how I present: no feature demos, a roadmap the prospect pins themselves on, and a profit calculator that runs THEIR numbers.

My business: [what you sell, who buys it, your price, the result a client gets]

Build me:
1. My roadmap: 5 to 7 steps a client goes through from where they start to the result, each step named in 3 words or fewer, in plain language a stranger understands. Tell me which steps are usually "already done" by the prospect so the pin question works.
2. My profit calculator: the 3 or 4 numbers I should ask the prospect for, the formula that turns them into a weekly or monthly leak, and the hidden row that turns it into a yearly number. Use realistic example numbers for my niche and show the math worked out.
3. The 3 lines I say out loud: the line that introduces the roadmap, the pin question, and the line that reveals the yearly number. Short, spoken, no jargon.

Then pressure test it: play a skeptical prospect who says "those numbers seem high" and show me how to respond using only questions that make the prospect re-confirm their own inputs.
```
