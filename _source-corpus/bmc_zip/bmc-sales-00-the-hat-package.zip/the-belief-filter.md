# The Belief Filter

Yo! It's RyMac. Here is the rule I hold, and I want you to take it.

People hit me up all of the time to come in and figure out how to close their
deals, so they can hand it off and their sales team can do better. I say no to
most of them, and this is why.

## The rule, both halves

**I will only close on things I believe will help people.**

**I won't close things that I don't believe will help people.**

Both halves matter. The first one gives you the duty. The second one is what
keeps you a closer.

## Why you cannot keep only the first half

Take just the first half and you get a very familiar guy: the one who has
convinced himself that everything he closes on helps people, because he is the
one closing it. That is not a filter. That is a permission slip.

The second half is a filter because it has teeth. It costs you money. It means
turning down deals you could close, in months where you would rather not.

A rule that never costs you anything is not a rule. It is a slogan.

## What it buys you

Every skill in this course gets sharper the more you use it, and sharper tools
do more damage in the wrong hands. The filter is what decides whether 19 years
of getting better at this makes you somebody people thank, or somebody people
avoid.

It also makes closing easier, which nobody believes until they try it. When you
genuinely believe the thing helps, you stop performing. You are not persuading,
you are explaining. The pressure comes off, and the calls get better.

## Run this prompt

```
You are helping me write and then APPLY my own version of the belief filter.

WHAT I OFFER: [plain words]
WHO IT GENUINELY HELPS: [be specific about the person and the situation]
WHO IT DOES NOT HELP, even though they might buy: [if you cannot think of
anybody, say that, because it usually means the filter has not been tested]
MY OPEN DEALS: [list each open deal: who they are, deal size, and whether
I actually think it will work for them]

Do this:

1. Write my belief filter as 2 sentences, matching this shape:
   "I will only close on ___ because ___."
   "I won't close ___ even when ___."
   Use my words, not generic ones.

2. Run it against my open deals. For each one, mark PASSES or FAILS the
   filter, with 1 sentence of reasoning.

3. For anything that FAILS, write what I say to walk away without burning the
   relationship. Honest, short, no apology.

4. Add up the revenue I would give up by honoring the filter. State the number
   plainly. Do not talk me into or out of it.

Rule: a filter that costs nothing is not a filter. If everything in my open
deals passes, be suspicious and tell me why.
```
