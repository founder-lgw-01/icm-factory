# Member Builds: the room record

This file is the community's rep log for the live sparring drop. Run a rep with the files in this package, post what happened in the community, and you go in here, name kept. Ugly reps welcome. Ugly reps posted beat perfect reps imagined.

What earns a spot:

- You ran the sparring prompt and posted the scorecard, especially the 1 line where you lost control.
- You rebuilt the 6 stages for your business and posted your doctor frame or commitment question.
- You caught something in the live call the room should see: a stage flip, a handler, a moment the framework saved.
- You closed something real using a handler from this package. Receipts get top billing.

Format per entry: name, what they ran, the 1 thing worth stealing, and a link to their post.

---

*(This file ships empty on purpose. It fills up as the room posts. First rep posted goes first.)*
