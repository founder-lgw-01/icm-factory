# Member Builds: the Deal Autopsy drop

This is the room record for this drop. Ran the autopsy on 1 of your own dead deals? Adapted the 1-10 handler? Murder-tested an AI you built? Post it in the community and you go in this file.

Format per entry:

## [Name]
- **What they ran:** (autopsy / 1-10 handler / murder test)
- **The body:** 1 line on the deal or tool they tested
- **The ruling:** what the coroner (or the test) found
- **The keeper:** the 1 line worth stealing from their post

---

*Empty so far. First body on the table gets the top slot.*
