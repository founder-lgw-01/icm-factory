# Term Sheet: every term from the video, 1 line each

- **Ally**: the name of the AI front desk person. Dr. Chen's Ally answers
  his practice's calls and books appointments.
- **AI front desk**: a computer employee that answers every call in your
  business's voice and runs your call flow, so no call goes to voicemail.
- **Sell first, build second**: close the deal before you build the thing,
  so you get paid to build instead of building and begging.
- **The framework**: my sales stages, in order: Pre-call, Rapport, Diagnose,
  Get a Commitment, Present, Test Close, Close.
- **Rapport**: the warm open that lands the trust frame, the moment the
  caller decides you are the right place.
- **Diagnose**: the exam questions right after the frame lands. You are the
  doctor now: what hurts, how long, what have you tried.
- **Get a Commitment**: the hinge question: do you want this handled now, or
  do you want to wait it out?
- **Test Close**: a small question (like the 1 to 10 pain scale) that lets
  the caller sell themselves before you ask for anything.
- **The trust frame**: 1 sentence of real proof in the business's voice:
  "Dr. Chen has helped 1,000s of patients over the last 10+ years."
- **Her page**: the 1-page plain-English write-up of who she is, her call
  flow, her objection answers, and her nevers. Her whole brain, readable.
- **The nevers**: the short list of things she may never say: prices she
  can't quote, promises she can't make, topics that go to a human.
- **ICM folders**: Jake Van Clief's system of organizing a build as plain
  folders and text files your AI can read, so the map itself does the work.
- **Seat / account**: her home inside the platform. Each business gets its
  own isolated workspace, and she is that workspace's employee.
- **Booking page**: the public calendar link where a caller's appointment
  actually lands, with real hours and real rules.
- **Smoke test**: the first live end-to-end try, designed to find what
  breaks before a real customer ever does.
- **Grade sheet**: the written pass/fail list a test call gets scored
  against, line by line, from the transcript.
- **Spell-back**: her habit of reading a name or email back letter by
  letter before booking. The letters win over what a word sounded like.
- **Timelapse (the 12x moments)**: parts of the build where I muted and the
  video speeds up 12 times so you skip the waiting, not the work.
- **The terminal**: the plain text window where I type instructions to my
  AI and it does the work. Looks scary, is just a chat box.
- **Cold open**: the video's opening clip, the real $4,000 close, before
  anything else plays.
- **9 cents a minute**: my real, measured cost of AI call time because I own
  the wiring instead of renting a middle-man platform.
- **The 65% floor**: my pricing rule: at least 65% of every dollar charged
  survives after delivery costs, or the offer does not ship.
