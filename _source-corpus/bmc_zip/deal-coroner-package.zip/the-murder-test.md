# The Murder Test

An AI that sounds smart is not the same as an AI that is right. Every AI sounds smart. That is the whole problem.

When I built the deal coroner, the demo looked great on day 1. Confident rulings, clean language, quoted evidence. And I had no idea if any of it was true, because I fed it calls where I did not know the answer either. An AI grading mystery meat is just 2 of you guessing.

So I murdered 2 deals. Here is the method, and it works for ANY AI you build or buy:

1. Create ground truth. I called my AI sparring partner, Dr. David Chen, and ran 2 real sales calls where I planted exactly 1 known mistake per call. Call 1: I pitched a price at 23 seconds with 0 diagnosis. Everything else I played straight.
2. 1 planted mistake per call, never 2. If you plant 3 mistakes you cannot tell which one the AI found or whether it just got lucky pointing anywhere.
3. Test blind. The coroner got the transcript and nothing else. Not "I think I pitched too early," not a hint, nothing.
4. Score against the plant. Did it name the planted mistake as the cause? Did it quote the actual moment? Did it stay calm about everything I did right? A diagnostician that flags 12 things when 1 is broken failed the test too.
5. Only after it passes on known bodies do you let it rule on unknown ones.

The bonus finding: the coroner also surfaced 4 chances the prospect handed me that I never heard live. Ground truth testing does not just validate the tool, it shows you what the tool sees that you cannot.

This is the difference between a demo and an instrument. Demos impress. Instruments get tested against known answers before you trust them with unknown ones.

## Run this prompt

```
I have an AI tool or workflow I want to trust: [describe what it does, e.g. "reviews my sales calls", "audits my landing pages", "screens resumes", "diagnoses why my ads underperform"].

Design a murder test for it:

1. GROUND TRUTH: Tell me exactly how to create 2-3 test cases where I already know the right answer, using my real materials. For each case, what is the 1 known failure I should plant, and what does "everything else done right" look like so the plant is the only real flaw?
2. THE BLIND RUN: Write the exact input I should give my AI for each case, with zero hints about what was planted.
3. SCORING: Give me a pass/fail rubric: found the planted failure, quoted the actual evidence, did NOT flag a pile of false positives, confidence stated honestly. Define what score means I can trust it on unknown cases.
4. THE TRAP: Tell me the most likely way my AI will LOOK right while being wrong on this test, so I know exactly what to watch for.

Then ask me for my first test case and walk me through running it.
```
