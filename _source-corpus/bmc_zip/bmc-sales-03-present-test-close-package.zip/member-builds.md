# Member Builds: the room record

This file is the community's trophy wall. When you run the prompts in
this package on your own offer and post what came out, you go in here,
name kept. The record grows with every drop.

Why it exists: seeing a name you recognize next to a real roadmap, a
real Test Close sheet, or a real close line beats any testimonial. This
room ships.

## The record

<!-- One block per member, newest on top. Format:

**[Name]** · [what they built or contributed] · [link to their post if in
the community] · [the one line worth remembering from it]

-->

(First member to post a build claims the top spot.)

## How to get in here

1. Run a prompt from any file in this package on your own business: the
   roadmap, the Test Close call sheet, or the close script and sheet.
2. Post what came out in the community. Rough is fine. Shipped beats
   perfect. Bonus points if you ran it on a real call and report what
   the prospect actually said.
3. Tag the post with which file you used. I read all of it, and builds
   that teach the room something get added here with your name on them.
