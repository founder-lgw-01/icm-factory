# Term Sheet: What Sales Is & What It Isn't

Every term from the lesson, 1 line each, in plain words. If you have never closed anything, start here.

**Sales** · helping somebody with a real problem decide you have the answer, and being thanked for it after they have paid you.

**Framework** · the repeatable set of steps you run on every call, so the call has a shape even when the conversation goes off the page.

**7 steps, 3 objection handlers** · the whole framework, taught free across the rest of this course; the steps by name are Lurk, Rapport, Diagnosis, the Commitment, Present, the Test Close, and the Close.

**Prospect** · the person you are talking to who might become a customer.

**Salesman** · somebody who lets their prospects lie to them, takes the polite exit, and chases dead deals for weeks.

**Closer** · somebody who does not lie to their prospects and does not let their prospects lie to them; the standard held on both sides of the call.

**The hat** · that closer standard, put on deliberately before every call; not a personality, not a voice, a choice.

**Manipulator** · somebody running the exact same skills with the money pointed the wrong way; same framework, opposite intent.

**Commission** · the cut a rep earns on a deal; chasing it is one of the things sales is NOT.

**Clear path** · showing somebody the route from where they are to where they want to be; that is the whole job.

**Diagnosis** · finding out what is actually wrong before you offer anything; until you have done it, you have no right to close.

**The duty to close** · once you have diagnosed a real problem you can fix, closing them IS the help; letting them walk leaves them with the problem.

**The bottle of water** · the picture behind the duty: they are dying of dehydration, you have the water, and handing it over is not pushy.

**Earn the credit card** · getting to the payment through honesty, diagnosis, and a clear path, never a trick; the opposite of a swipe you talked somebody into.

**For them vs off them** · the direction the money flows in your head: making money by helping the people around you, or making money off the people around you; 1 word, the whole difference.

**Drift** · the slow slide from for them to off them; nobody decides to become a manipulator, they drift there, usually when money gets tight.

**The mirror test** · can you look at yourself at the end of the day and like what you see; the only scoreboard that catches drift.

**The belief filter** · the 2-sided rule: only close on things you believe will help people, and refuse to close things you don't believe will help, even when you could.

**Cold call** · calling somebody who was not expecting you; the skill everything else in sales sits on.

**Go be dangerous** · the send-off: you now know enough to do real damage, so go use it for people, never on them.
