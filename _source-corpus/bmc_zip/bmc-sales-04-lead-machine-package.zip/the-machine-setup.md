# The Machine Setup

Yo! It's RyMac. Before we write a single word of copy, we build the plumbing.
Because the best sales machine on earth starves without at-bats, and cold
email is the machine that feeds the machine. Full credit where it's due: the
infrastructure playbook here is Lead Gen Jay's (Jay Feldman). I've run his
system for years. Jay is to lead gen what I am to closing. He's better at
that. I'm better at this. We're both dangerous.

Built right, this machine produces. My best campaign ran a 16% reply rate:
45 replies from 278 leads. Jay's benchmark ladder says the industry average
is a 1 percent reply rate, 3 percent is good, and 6 percent is elite. So
here's how you build for elite.

## Rule 1: never send cold email from your real domain

1 spam blacklist and your whole business email is radioactive. So you buy
lookalike domains. getyourbrand.com. tryyourbrand.com. They redirect to your
real site. If one burns, your house doesn't.

## The ratios are not negotiable

- 3 mailboxes per domain.
- 30 cold sends a day per mailbox.
- Want more volume? Add more domains. Never crank the dial on one.

That's roughly 90 cold sends a day per domain, max. Do the math backwards
from the volume you want and buy that many domains. Cranking one domain past
the line is how you end up on the blacklist from rule 1.

## Authenticate everything

SPF, DKIM, DMARC, on every sending domain. Google and Yahoo don't filter
unauthenticated mail anymore. They reject it. Not spam folder. Rejected.
This is a 1-time setup per domain and it is not optional.

## The part nobody wants to hear: warmup

New mailboxes send tiny amounts for 4 to 6 weeks before the first real
campaign. Skip this and you're spam-foldered before you say a word.

The cheat code: pre-warmed accounts exist. Instantly offers mailboxes that
already did their 4 to 6 weeks, so you skip the line and can be sending
real campaigns the same week you build your list. That's a paid shortcut,
not a requirement. The free version of the cheat code is patience: buy the
domains today, start the warmup today, and write your list and copy while
the clock runs.

## Run this prompt

Paste this into your AI with this file:

```
My business: [WHAT YOU OFFER AND WHO IT'S FOR]
My real domain: [YOURBRAND.COM]
Cold sends I want per day once ramped: [NUMBER, e.g. 90, 180, 270]
My timeline: [WHEN I WANT THE FIRST REAL CAMPAIGN GOING OUT]
Budget comfort: [ROUGH MONTHLY NUMBER, OR "as cheap as possible"]

Using the rules in this file (never send from the real domain, 3 mailboxes
per domain, 30 sends a day per mailbox, authenticate everything, 4 to 6
weeks of warmup):

1. Tell me exactly how many lookalike domains and mailboxes I need for my
   target volume, and show the math.
2. Propose 6 to 10 lookalike domain names for my brand (get/try/use style)
   and flag any that look spammy or too far from my real name.
3. Give me the setup checklist in order: register domains, redirect them to
   my real site, create mailboxes, then SPF, DKIM, and DMARC, with a 1-line
   plain-language note on what each record does.
4. Build my warmup calendar from today: what happens in weeks 1 through 6,
   and the earliest safe date for my first real campaign. If my timeline
   doesn't allow the warmup window, say so plainly and give me both options:
   wait it out, or buy pre-warmed accounts to skip the line.
5. Finish with the 3 mistakes most likely to burn my domains in the first
   90 days, based on my answers above.
```

Always got your back,
RyMac
