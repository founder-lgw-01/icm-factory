# The 6-Stage Framework

Sales is a framework, not a script. Scripts are "if they say this, you say that" crap. They collapse the moment the prospect goes off the page, they make you sound like a robot, and they are not necessary. A framework works in any sales environment, you learn it once, and it works forever. You always know where you are and what comes next, which is exactly why the conversation feels normal instead of robotic.

It took 25 years to build. It takes 10 minutes to learn. Hours of practice make it second nature.

There are 6 stages. Every stage is insurance for a later stage. Skip 1, and you pay for it later, when the truth gets expensive.

## Stage 1. Pre-call

15 minutes of homework on the prospect before you ever dial. Weave 1 or 2 facts in naturally during the call. Never recite the file. You did research to sound informed, not to prove you did research.

## Stage 2. Rapport Building

Find common ground, then land the frame:

> "I want you to think of me as your business doctor. I'm going to ask questions to diagnose if I can help you or not. If I can't I'll refer you to a specialist, but if I can I'll prescribe you the solution. Does that make sense?"

It has to end in a yes. A doctor does not prescribe before examining you. Once the frame lands, everything after it is diagnosing, and pushy questions stop feeling pushy because a doctor is supposed to ask them.

You should not need more than 10 questions, 15 minutes or under. We are not interviewing. Early questions dig for the pain. Middle questions make sure they can make the decision and no one else is needed. Late questions put them in the future they want. A few to get you going:

- "What drove you to take this call with me today?"
- "What exactly is going on?"
- "What have you tried to do to fix it?"
- "Does anyone else need to be on this call?"
- "If I waved a magic wand and it's 1 year from today, where are you, so happy with your business that you're chasing me down to tell me?"

Find pain. Make sure they can decide. Figure out where they are. Put them in a happy future.

That question about anyone else being on the call is not small talk. It puts a spade in your pocket for later. You will see it again in the handlers file.

## Stage 3. Get a Commitment

This is the stage almost no one does. The exact words:

> "Great news, I can help you get to that goal. Before I show you how, I wanted to know that if everything makes sense, would you be opposed to moving forward with me at the end of this call?"

Catch that? You asked for a no. This is the only time no means yes. A yes feels like pressure. A no feels safe to say. Ask a yes question here and their guard goes up. It is human instinct. So you get the commitment easier, and now there is a second spade in your pocket.

## Stage 4. Present

Present that you can get them where they want to be. Never demo the tech. Features and benefits overwhelm the prospect and create more questions, and questions make your path to the close harder. Weeds don't close deals.

The last time you had a fantastic meal at a restaurant, did the cook come out and break down the entire recipe? Or did you just enjoy the steak?

Show them a roadmap, then ask which step they are on. Whatever step they pick, the steps they have not reached ARE the offer. Nobody argues with their own pin. Then show them a profit calculator, have them enter their numbers, and let it calculate their ROI based on what they said. Math is impossible to object. 2+2=4, on any day that ends in Y. The math file in this package goes deep on this stage.

## Stage 5. Test Close

They told you their pains. You showed them a clear path. Before any money ask, you simply ask:

- "How does everything look so far?"
- "Is this making sense to you?"
- "Do you see this not working for you?"

You have not shown a price yet, so real objections surface here, and this is your chance to understand what they are really thinking. The lies, also known as objections, start after you show your price.

## Stage 6. Close

Eventually they ask what it costs.

> "It costs $7,500 to get started. What would you like to do next?"

Then silence. Do not say another word. Mute yourself if you have to. If you followed the framework, you will hear "Damn, that's a good question... let's get started." I know because I have heard it, and you will too.

If an objection comes back instead, that is what the 3 handlers are for. Every handler ends in a question, and then you close again.

## Run this prompt

Paste this file into your AI, add your own details where marked, and run it:

```
You are my sales trainer. Above is the 6-stage sales framework I follow: Pre-call, Rapport Building, Get a Commitment, Present, Test Close, Close.

My business: [what you sell, who you sell it to, your price, and how calls get booked]

Rebuild every stage in my words for my business:
1. Pre-call: the 5 things to research on my exact kind of prospect in 15 minutes, and 2 example ways to weave a fact in naturally.
2. Rapport Building: my version of the business doctor frame, worded for my industry, plus 10 diagnosis questions in the early/middle/late order the framework requires, ending with my version of the magic wand question.
3. Get a Commitment: my commitment question, worded to ask for a no.
4. Present: my roadmap of 5 to 7 steps a client goes through with me, and the 3 numbers my profit calculator should ask for.
5. Test Close: 3 temperature questions in my voice.
6. Close: my exact close line with my real price, followed by the reminder to go silent.

Keep every line short enough to say out loud without reading. When you are done, quiz me: play a prospect and make me run stages 2 and 3 on you, and grade whether I landed the frame and got the commitment.
```
