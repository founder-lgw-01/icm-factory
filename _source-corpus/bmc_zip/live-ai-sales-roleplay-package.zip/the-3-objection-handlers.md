# The 3 Objection Handlers

All objections are lies. Not evil lies. Polite ones.

Proof: ever been asked if you like someone's food, by them? Maybe if they look good in these jeans? Even though you had to chase grandma's broccoli casserole with a Pepsi, you said "it's good, thank you for making it." People lie to be nice. "Follow up with me in 2 weeks" is them saying no, but being nice about it.

Here is the 2-weeks play from the video, word for word:

> "Let me ask you this, John. I've been told to follow up in 2 weeks 100s, if not 1000s, of times. Out of, let's say, 100 of those, how many do you think actually pick up the phone and do business with me in 2 weeks?"
> "Ummm, I don't know."
> "0, John. What I think just happened here is you were really telling me no, and you didn't want to hurt my feelings. So you were being nice about it, is that the case?"

Your job is to get to the truth, kindly. You do not need a thousand rebuttals. You need 3 ways to handle any and all objections.

## Handler 1. The Spade

You call out the lie, respectfully. Always lead in with something like "I'm confused." Confusion is authentic. "Hold up" is confrontational.

They say: "I need to talk to my wife first."

> "I'm confused. At the start of the call you said no one else needed to be on this call. And that you would not be opposed if everything makes sense. Normally, John, when people say that, they're really telling me no and don't want to hurt my feelings. Is that what just happened here?"

The spade gets to the truth in 1 question. Notice it only works because stages 2 and 3 put those 2 commitments in your pocket. That is what "every stage is insurance for a later stage" means.

## Handler 2. Isolation

Objection, answer, new objection. I have seen this loop last 45 minutes, it is just silly. That loop is how you lose control. So get every question on the table first:

> "Great question. Our best customers asked the same thing before they got started. I'm going to answer it, but before I do: is there anything else holding you back, or is it just about [the thing they said]?"

They will either say "nope, it's just about that," or they will give you other questions to handle. Then you go back to the original objection: "So back to the first question..." Handle it, then close.

## Handler 3. The 1-10 double tap

They say: "I need to think about it."

The cadence is the juice here. You double tap with 2 questions, as if you thought of a better question. The first one gets them thinking about what they are thinking about. The next one lets them easily score themselves. They are probably expecting the first question, so the switch feels like a favor, not a trap.

> Tap 1: "That makes sense, it's a big decision John. While you got me, what are you thinking about?"
> Tap 2: "Actually, let me ask you this way: on a scale of 1 to 10, 1 meaning I wish I never showed up to this call, what a waste of time, and 10 being I'M READY RIGHT NOW! Where are you?"

They say 7.

> "Sweet. What would it take to get you to a 10?"

They will tell you exactly what their closing conditions are. You are now the order-taker for their own list.

The below-5 rule: 5 and above means you should be able to close them. Anything below is their way of saying not even close, but in a nice way. If you catch a random 3, say this in a fun, self-deprecating way: "Holyyy crap, I must have really messed up? Is it even possible to get you to a 10?" It lets them off the guilt hook, and it gets you to the truth easier.

## The closer's code

You can't spade everything. You can't isolate everything. You can't 1-10 everything. But you can use them interchangeably. Every handler ends in a question, then you close again.

I personally will take at least 3 swings. I will find out the truth. I will close them if they are closeable. I won't lie to them. And more importantly, I won't let them lie to me. Just like respect is earned, so are closes.

In the live call in the classroom, I had to use 2 of the 3. Listen closely and catch which 2.

## Run this prompt

Paste this file into your AI, add your details, and run it:

```
You are my objection-handling coach. Above are the only 3 objection handlers I use: the Spade (call out the lie respectfully, using commitments from earlier in the call), Isolation (get every question on the table before answering any), and the 1-10 double tap (2 questions back to back, then "what would it take to get you to a 10").

My business: [what you sell, your price, who the buyer is]
The 5 objections I hear most: [list them in the prospect's exact words]

For each of my 5 objections:
1. Tell me which handler fits best and why in 1 sentence.
2. Write the handler script in my voice, using the templates above, with my objection filled into the brackets.
3. Keep every line sayable out loud. No corporate words.

Then run me through a drill: play a prospect who throws my objections at me 1 at a time, in random order, and after each of my answers grade me on 2 things: did I use the right handler, and did I end with a question. Do not go easy on me. If I answer an objection without isolating first, call it out.
```
