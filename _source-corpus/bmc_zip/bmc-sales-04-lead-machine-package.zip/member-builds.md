# Member Builds: the room record

This file is the community's trophy wall. When you build your lead machine
with the files in this package and post it in the community, you go in
here, name kept. The record grows with every drop.

Why it exists: seeing a name you recognize next to a real build beats any
testimonial. This room ships and this room checks receipts.

## The record

<!-- One block per member, newest on top. Format:

**[Name]** · [what they built or contributed] · [link to their post if in
the community] · [the one line worth remembering from it]

-->

*(First member to post a build claims the top spot.)*

## How to get in here

1. Run a prompt from any file in this package on your own business.
2. Post what came out in the community: your domain plan, your list spec,
   your opener and follow-ups, your first reply-rate numbers, whatever it
   is. Rough is fine. Shipped beats perfect.
3. Tag the post with which file you used. I read all of it, and builds that
   teach the room something get added here with your name on them.
