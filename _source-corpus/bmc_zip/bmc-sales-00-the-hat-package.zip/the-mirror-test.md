# The Mirror Test

Yo! It's RyMac. This is the part of the video I did not enjoy recording, and it
is the most useful thing in it.

## What happened

I found tremendous success when I focused on helping everyone around me make as
much money as possible. I believed that if I did that, the money would come and
it surely did. I generated millions of dollars in sales every year by helping
everyone around me first and foremost. My intentions were pure.

Then I lost sight of that. And I started trying to make as much money off of
everyone around me as possible. My intentions weren't pure anymore. And I lost
it all.

Same skills. Same framework. Same words.

**1 word changed. For them, became off them.**

And that is why at one point in my life I couldn't look myself in the mirror.

## Why this is the whole thing

Every other lesson in this course is a technique. Techniques are neutral. The
exact same 7 steps, the same 3 objection handlers, the same questions, run by 2
different people, produce a closer and a manipulator.

The difference is not the method. It is which direction the money flows in your
head.

**Closers can look themselves in the mirror everyday and like what they see.
Manipulators can't.** I know, because I've been on both sides.

## The part nobody warns you about

I did not wake up one day and decide to become a manipulator. I drifted. It
happens slowly, usually when things get tight, and the tell is that you start
optimizing for the number instead of the person, and you tell yourself it is
temporary.

So the test is not "am I a good person." Everybody passes that one. The test is
in your actual decisions: your pricing, who you take on, what you do when
somebody is a bad fit and you need the revenue this month.

## Run this prompt

```
You are running the mirror test on my business. Be blunt. I am not looking for
encouragement.

WHAT I OFFER: [plain words]
MY PRICE: [number]
WHAT IT COSTS ME TO DELIVER: [time and money]
MY LAST 3 CLIENTS: [for each: were they a good fit, did they get the result,
would I take them on again]
A TIME I TOOK ON SOMEBODY I SHOULD NOT HAVE: [what happened, and why I did it]

Do this:

1. For each of my last 3 clients, tell me whether that deal was FOR them or OFF
   them, based on what I told you. Say which and why in 1 sentence each.

2. Look at my price against what I deliver. Tell me if it is fair, generous, or
   extractive. If you cannot tell from what I gave you, say what is missing.

3. Name the specific pressure most likely to make me drift. Money, ego,
   a quota, a slow month, whatever my answers point at.

4. Write me 1 question to ask myself before I take on a new client. It must be
   answerable yes or no in 5 seconds.

Rule: if my answers show I have already drifted, say so plainly. Do not soften
it.
```
