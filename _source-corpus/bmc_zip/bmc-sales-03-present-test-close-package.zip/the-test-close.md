# The Test Close

Yo! It's RyMac. The roadmap landed. Do not ask for money yet. Test
first. That is the whole job of the Test Close.

## The 2 questions

"How does everything look?"

"Do you see this NOT working for your business?"

That's the whole stage. 2 questions, then you listen.

## Why this stage exists

Real objections surface here, while they still cost nothing. The lies
start after you go for the close.

Before the price, a question is just a question. Answer it, then ask:
"does that make sense?" Then keep flushing.

## When they jump to price

If they jump straight to "what's the price?"

Good sign. Do not answer it yet. The line, word for word:

"We're about to get to that. Other than price, are there any other
questions or concerns, or is price the only thing you need to know?"

Flush every question and concern out first. Then, and only then, the
close.

That last question is doing heavy lifting. If they say "price is the only
thing," they just told you the deal is closed except for a number. If
they surface something else, you just caught an objection while it was
still cheap. Either answer wins.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT IT IS AND WHO IT IS FOR]

My price: [WHAT IT COSTS TO GET STARTED]

How my presentation currently ends: [THE LAST THING YOU SAY OR SHOW
BEFORE MONEY COMES UP]

The 5 objections I hear most: [LIST THEM IN YOUR PROSPECT'S OWN WORDS]

Using the method in this file:

1. Script my Test Close: the 2 questions from this file, placed
   naturally in my own presentation flow, in my own words where the file
   allows it and word for word where it doesn't.
2. For each of my 5 objections, write a plain-language answer under 60
   seconds spoken, ending with "does that make sense?" No hype, no
   pressure, just the answer.
3. Write my price-jump response using the exact "We're about to get to
   that" line from this file, adapted only where my offer's wording
   requires it.
4. Build me a 1-page call sheet: the Test Close questions at the top,
   the 5 objection answers under them, the price-jump line at the
   bottom, and a rule box that says the close does not start until every
   question and concern is flushed out.
5. Flag anything in my current presentation that invites objections to
   hide until after the price, and tell me what to move earlier.
```

Always got your back,
RyMac
