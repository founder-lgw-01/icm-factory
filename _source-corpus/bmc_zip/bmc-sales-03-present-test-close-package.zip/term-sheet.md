# Term Sheet

Every term from the video, in plain language. No question in the
community is too basic; this file exists so you never have to ask "wait,
what's the pin?"

**The machine** · The whole model: sales is a set of stages that run in
order, and each stage's job is to make the next one cheap. Not a script
you recite, a machine you run.

**Stage** · 1 station in the machine. This video covers Present, the
Test Close, and the Close. The ground before them: Lurk, Rapport,
Diagnosis, and the Commitment.

**The Commitment** · The yes you pocketed before this video starts. The
prospect said "No, I wouldn't be opposed if everything makes sense."
Present, the Test Close, and the Close cash that sentence in.

**Present** · Showing the prospect the path from their pain to their
happy future. A roadmap, never a demo.

**Demo** · Walking a prospect through your product's features on screen.
The thing this video tells you to almost never do.

**The whiz-bang** · The shiny thing you built. Beautiful. 17 features.
Nobody buys the whiz-bang; they buy the happy future.

**The weeds** · The feature-level details of the whiz-bang. Weeds don't
close deals; they make prospects think, and thinking out loud sounds
like "let me think about it."

**3 minutes, tops** · The maximum time to spend inside the product.
Prove it exists. Get out.

**Roadmap** · A 1-page list of numbered steps, grouped in phases, from
the prospect's pain to their result. Mine was 9 steps in 3 phases. The
steps they haven't reached yet ARE the offer.

**The pin** · Where the prospect places THEMSELVES on the roadmap when
you ask "which step are you currently on?" Nobody argues with their own
pin.

**Ally energy** · Framing their pin as progress, not deficiency. "Great
news, most people are much further behind." You are on their side of
the table.

**The Test Close** · Checking the temperature before asking for money.
"How does everything look?" and "Do you see this NOT working for your
business?"

**Objection** · Any reason not to buy. Real ones surface at the Test
Close while they cost nothing. The lies start after you go for the
close.

**The flush** · Pulling out every question and concern BEFORE saying
the price, so nothing is left hiding behind it.

**The price jump** · When the prospect skips ahead to "what's the
price?" A good sign. You do not answer it yet.

**The Close** · 1 line and 1 question: the price, then "what do you
want to do next?"

**The silence** · What you do after the closing question. Not another
word. Mute yourself if you have to. The silence is doing the closing.

**Profit spreadsheet** · The sheet built live on the call out of THEIR
numbers: their leads, their average sale, their close rate. Agree,
agree, agree, reveal.

**The hidden row** · The 1 cost row kept hidden until they've agreed
to every number above it. Unhide it and their own sheet shows the ROI.

**ROI** · Return on investment. What they get back compared to what
they pay. On their own sheet it was some crazy number like 3,000%.

**Close rate** · The percent of pitches that become closed deals. The
roadmap move ran a 71% close rate on a $30,000 offer.

**Sales cycle** · How long a deal takes from first touch to money. The
spreadsheet deals ran a 64-day cycle and still closed in 1 call at the
end.

**Unpaid debts** · Objections at the close. Each one traces back to a
stage you skipped. Run the stages in order and there's nothing left to
object to.
