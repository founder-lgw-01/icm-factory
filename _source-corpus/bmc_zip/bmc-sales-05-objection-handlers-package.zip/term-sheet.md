# Term Sheet

Every term from the lesson, in plain language. No question in the community
is too basic; this file exists so you never have to ask "wait, what's a
spade?"

**Objection** · The reason a prospect gives for not buying right now. "I
need to talk to my wife." "Let me think about it." "Follow up in 2 weeks."

**Polite lie** · What almost every objection really is. The prospect is
telling you no (usually about price) but doesn't want to hurt your
feelings, so they dress the no up as something nicer.

**Handler** · A repeatable way to respond to an objection. The lesson's
whole point: you need exactly 3, not 1,000.

**The rebuttal binder** · The guru product: 1,000 "if they say this, you
say that" flashcards. Collapses on a live call.

**The spade** · Handler 1, from "call a spade a spade." You name the
polite lie, kindly, and ask about it. Always opens with "I'm confused."

**"I'm confused"** · The 2 words that open every spade. Confusion is
authentic; "hold up" is confrontational.

**The Commitment stage** · The point early in the call where they agree
they would not be opposed if everything makes sense. The spade leans on
it. No commitment, no spade.

**The deposit hold** · The counter when they double down on needing to ask
someone: hold the price with a refundable deposit and settle the rest
after the talk. A refusal there tells you everything.

**The surgical question** · "Why do you think SHE would say no?" Whatever
they answer is the real objection. The wife was never the objection.

**The big-boy line** · "I'm a big boy, you can just tell me no." The
respect play that ends the polite-lie game either way.

**Isolation** · Handler 2. Grab the FIRST objection, then pull every
other question onto the table before answering anything, so nothing is
left to ambush you afterward.

**The stack** · The pile of objections hiding behind the first one.
Objections love company; isolation flushes the whole stack at once.

**The money version** · Isolation's best trick. "So you do believe this
will help you, and it's just about pricing?" Their yes turns "too
expensive" into a payment plan conversation.

**The 1-to-10** · Handler 3, for "I need to think about it." Agree with
them, then ask where they sit on a scale from 1 ("I wish I never showed
up") to 10 ("I'm ready to start right now").

**Closing conditions** · What the prospect lists when you ask "what would
it take to get you to a 10?" Their own checklist for buying.

**Order-taker** · What you become once they list their closing conditions.
You're not persuading anymore; you're filling their order.

**Best-customer relate** · The control move of tying their objection to
your best customers ("our best customers asked the same thing before they
got started"), then taking the mic back.

**Taking the mic back** · Ending your answer with a question so control of
the call returns to you.

**Open questions** · "Got any questions?" An open invitation to get
hammered. Never offer it.

**The framework** · The stages every close moves through, in order: Lurk,
Rapport, Diagnosis, the Commitment, Present, the Test Close, the Close.
Each stage gets finished before the next one starts. Free at
buildmarketclose.com.

**Stage debt (unpaid debts)** · Objections at the close are unpaid debts
from stages you skipped. The objection isn't new information; it's an
earlier stage collecting what it was owed.

**Emergency kit** · What the 3 handlers are when you run every stage
clean. If they're your everyday toolbox instead, you're skipping stages.

**Sparring** · Practicing the handlers out loud against a prospect who
lies back (your AI, a partner, or the live AI sparring session in the
community classroom) so you fumble in private, not on a real deal. The
free chat version is the prompt in the Practice Before the Money Is Real
file.

**The 4-level ladder** · The sparring difficulty climb: Level 1 is a warm
referral who wants to buy, Level 2 is interested but nervous about money,
Level 3 is skeptical and stacks objections, Level 4 is sharp, busy, and
will end the call the second you waste a sentence.
