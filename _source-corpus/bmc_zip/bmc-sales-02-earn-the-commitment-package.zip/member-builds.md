# Member Builds: the room record

This file is the community's trophy wall. When you take the lines in this
package to a real call and post what happened in the community, you go in
here, name kept. The record grows with every drop.

Why it exists: seeing a name you recognize next to a real call beats any
testimonial. This room ships and this room checks receipts.

## The record

<!-- One block per member, newest on top. Format:

**[Name]** · [what they ran or contributed] · [link to their post if in
the community] · [the one line worth remembering from it]

-->

The record is open. First member to ask "would you be opposed" on a real
call and post about it claims the top spot.

## How to get in here

1. Run a prompt from any file in this package on your own business, then
   take the lines to a real call.
2. Post how it went in the community: the help statement you used, the
   moment you asked the commitment question, what they said, even the
   calls you walked away from. Rough is fine. A walk-away story counts as
   a win here.
3. Tag the post with which file you used. I read all of it, and calls
   that teach the room something get added here with your name on them.
