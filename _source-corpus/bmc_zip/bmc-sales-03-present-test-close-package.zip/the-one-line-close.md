# The 1-Line Close

Yo! It's RyMac. The Close. If you ran the machine in order, all the way
from Lurk through the Test Close, this is the easiest stage there is. If
you skipped stages, this is where the debt collector shows up.

## The close

1 line and 1 question:

"It costs $X,XXX.XX to get started. What do you want to do next?"

And then you shut up.

I mean it. DO NOT SAY ANOTHER WORD. Mute yourself if you have to. The
silence is doing the closing.

If the machine ran clean, you'll hear the most beautiful sentence in
sales: "Damn, that's a good question... let's get started."

## The whole back half inside 1 real deal

Remember the 64-day sales cycle? Here's how those calls actually ended.

I'd build a profit spreadsheet live on the call, out of THEIR numbers.
Their leads. Their average sale. Their close rate. They agreed to every
single row. The sheet totals it up: $270,000 in new revenue.

Then the Test Close: "I mean, so... do you not see this working for your
business?"

And they always said the same thing: "Well, no, I mean I see it
working... but what's the cost?"

So I unhide 1 row. Month 1: -$7,500. Their sheet. Their numbers. And
their ROI sitting right there, some crazy number like 3,000%.

"It's $7,500 to get started. What would you like to do next?"

Then silence. And what they wanted to do next was hand me the credit
card.

Agree, agree, agree, reveal. **Nobody argues with their own math.**

## Why the close is this small

See the machine now? Every stage made the next one cheap. The commitment
made the Test Close honest. The Test Close flushed the truth out before
the price. The close was 1 line, because every stage before it already
did the closing.

Objections at the close are just unpaid debts from stages you skipped.
Run the stages in order, and there's nothing left to object to.

You don't need a script. You need to know where you are. The method in
this file works with a pen and a spreadsheet.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT IT IS AND WHO IT IS FOR]

My price to get started: [THE EXACT NUMBER]

Numbers my prospect already knows about their own business: [E.G. LEADS
PER MONTH, AVERAGE SALE, CLOSE RATE, JOBS PER WEEK. LIST WHAT APPLIES.]

The result my offer improves: [WHICH OF THOSE NUMBERS GOES UP OR DOWN,
AND BY ROUGHLY HOW MUCH, HONESTLY]

Using the method in this file:

1. Write my close, word for word, using the 1-line-plus-question shape
   from this file with my real price in it.
2. Design my agree-agree-agree-reveal sheet: the rows in the exact order
   I should ask for them (every row a number the prospect supplies, not
   me), the total line the sheet builds to, the 1 hidden cost row, and
   the ROI line that appears when it's revealed. Keep the math honest;
   if my inputs make the ROI look fake, say so and fix the inputs.
3. Write the Test Close bridge that goes between the total and the
   reveal, using the questions from The Test Close file.
4. Give me the silence rules: the 5 things I will be tempted to say
   after the question, and what saying each one costs me.
5. Audit my current sales process against the full machine, Lurk,
   Rapport, Diagnosis, the Commitment, Present, the Test Close, the
   Close, and list my unpaid debts: which stages I'm skipping, and which
   close-time objection each skipped stage is creating.
```

Always got your back,
RyMac
