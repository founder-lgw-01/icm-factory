# Run Your Own Reps

Nobody gets good at handling "I need to run it by my partners" by reading about it. You get good by hearing it 30 times and answering it out loud. The reps are the product. This file is the practice system.

## Self-diagnose every call, even closes

In the live call in the classroom, I closed the deal, and I still graded myself on camera: I said UM way too much. In my defense, I made up the offer and the AI agency on the spot, but the point stands. You should self diagnose every call, even the ones you win. Wins hide mistakes better than losses do.

The 3 things to catch when you listen to any call, mine or yours:

1. Count the stages as you listen. Pre-call, Rapport Building, Get a Commitment, Present, Test Close, Close. Know which stage the call is in at every moment. If you cannot name the stage, that is the finding.
2. Catch the frames. The doctor frame landing is the end of rapport. Everything after it is diagnosing until the commitment question. If the frame never landed, everything downstream got harder for no reason.
3. Watch which handler comes out. When the prospect lies, and they will, name the handler in real time: Spade, Isolation, or the 1-10. Then judge whether it was the right one.

## The practice loop

1. Learn 1 framework cold. Not 5 frameworks a little.
2. Run a call against an AI prospect out loud, on voice. Text does not count. Typing objection responses trains your thumbs, not your mouth.
3. Lose. Note the exact line where you lost control of the call.
4. Run it again and fix only that line.
5. Grade yourself with the scorecard below. Post the ugly ones in the community. Ugly reps posted beat perfect reps imagined.

10 reps like that beat 10 hours of sales content.

My sparring gym does this against agents like Dr. Chen, the one from the video, and founding members get it free during the beta at buildmarketclose.com. But the prompt below works with any AI that has a voice mode, today, without buying anything. No excuses.

## Run this prompt

Paste this file into your AI (use voice mode if it has one), add your details, and run it:

```
You are my sales sparring partner. We are going to roleplay a sales call, out loud, and you are the prospect.

My business: [what you sell, your price]
The prospect you play: [their role, business type, and 1 real pain they have]

Your rules as the prospect:
1. You took the call willingly, but you are busy, a little skeptical, and you push back. Do not be easy.
2. Object with polite lies, never direct honesty: "I need to think about it," "I need to run it by my partner," "follow up with me in 2 weeks," "that's real money." Pick what fits the moment.
3. If I handle an objection well, soften a little. If I answer an objection without isolating first, stack a second objection on top.
4. If I sound like a robot, get boring, or pitch features instead of outcomes, start checking out. If I let the call drift for too long, say you have to jump to another meeting and end the call.
5. Never break character until I say the words "end rep."

When I say "end rep," become my coach and grade the call on this scorecard, quoting my actual lines as evidence:
- Did I land an authority frame in rapport (like the business doctor)? 
- Did I get a commitment before presenting, worded to ask for a no?
- Did I present outcomes and math, or did I demo features?
- Did I test close before showing the price?
- After the price, did I go silent?
- For each objection: which handler did I use (Spade, Isolation, 1-10 double tap), was it the right one, and did I end with a question?
- The 1 line where I lost the most control, and the exact words I should have said instead.

Then say "again?" and if I say yes, run a fresh rep with a harder version of the same prospect.
```
