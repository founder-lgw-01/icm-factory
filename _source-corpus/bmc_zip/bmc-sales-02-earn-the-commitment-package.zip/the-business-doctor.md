# The Business Doctor

Yo! It's RyMac. Rapport comes right after the Lurk: 1 or 2 minutes of real
common ground. No weather talk. 3 moves happen here, and by the end of them
you have permission to ask anything.

## Move 1: the opener

Mine opens like this:

**"Sooo, Claude, where are ya' at in the world?"**

(In the video my pretend prospect is named Claude. Use theirs.)

Whatever they answer, I can common-ground it. "San Diego? Nice, I was in
the Marines there." "Alabama? That doesn't mean you're a Bama fan, does it?
I grew up in Louisiana." That's the Lurk paying rent: you already know where
the overlap lives, so the common ground is real, not forced.

## Move 2: the help statement

When it fits, or when they ask what I do:

**"I help [who] [get the outcome] using my [whiz-bang] so they can [what
they'd rather be doing]."**

Filled in, mine sounded like this:

**"I help personal injury firms recover lost revenue from inbound leads
using my whiz-bang system, so they can focus on clients and not chasing
leads."**

**"Is this something you need help with?"**

Notice the shape of that. It ends in a question.

**Always end in a question. Never end in a sentence.**

Questions are what move the call forward. A statement just sits there. A
question makes them answer, and their answer carries the call to the next
stage.

## Move 3: the frame that runs the entire call

The Business Doctor. Word for word:

**"Thanks for taking the call with me today. I want you to think of me as
your business doctor."**

**"I am going to ask you some questions so I can diagnose what's going on
and prescribe what you need."**

**"Just like a doctor, if I can't help you, I will refer you to a
specialist. Does that make sense?"**

That has to end in a yes. Because you don't lie to your doctor. And you're
not offended when your doctor asks where it hurts.

That one frame just licensed every intimate business question you're about
to ask. Skip it and Diagnosis feels like an interrogation. Land it and
Diagnosis feels like a checkup.

## Run this prompt

Paste this into your AI with this file:

```
My business: [WHAT YOU OFFER, WHO BUYS IT, AND THE RESULT THEY GET]
What my buyers would rather be doing than dealing with the problem I
solve: [FILL IN]
What I call my system or method: [FILL IN, OR SAY "PROPOSE ONE"]

Using this file (the help statement + the Business Doctor frame):

1. Write my help statement in the exact shape: "I help [who] [get the
   outcome] using my [whiz-bang] so they can [what they'd rather be
   doing]." Then add the closing question: "Is this something you need
   help with?" Give me 3 versions and mark the strongest.
2. Adapt the Business Doctor frame to my words WITHOUT changing its 3
   beats: thank them for the call, ask permission to diagnose and
   prescribe, promise the specialist referral if I can't help. It must
   end in a question that gets a yes.
3. Check every line you wrote: does it end in a question where it should?
   Fix any that end in a sentence.
4. Give me 2 common-ground openers for the first 2 minutes that are not
   weather talk, based on my typical prospect: [WHO YOU USUALLY CALL].
```

Always got your back,
RyMac
