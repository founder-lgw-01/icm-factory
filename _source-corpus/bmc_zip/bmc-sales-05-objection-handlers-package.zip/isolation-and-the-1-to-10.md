# Isolation + The 1-to-10

Yo! It's RyMac. Handlers 2 and 3 live in 1 file because they solve the same
problem from 2 sides: getting the REAL list on the table so you can close
it off, instead of chasing objections 1 at a time forever.

## Isolation: flush the stack

Objections love company. Answer 1, another appears. Answer that, here comes
a 3rd. That loop is how you lose a call. So grab the FIRST one and flush
the rest:

"Great question. Our best customers asked the same thing before they got
started."

"Before I answer it: are there any OTHER questions?"

Now the whole stack is on the table. Answer it all, close off the original,
done. Nothing left in the chamber to ambush you with.

## The money version

My favorite. They say "it's too expensive."

"So you do believe this will help you, and it's just about pricing?"

They say yes. And that yes is everything:

"PERFECT! That's the easiest part. If it's just about the money, what can
you swing today?"

The objection just became a payment plan.

## The 1-to-10: for the softest lie of all

"I need to think about it." Never argue with it. Agree with it:

"Makes sense, our best customers needed to think about it too."

"Let me ask you this real quick: on a scale of 1 to 10, where 1 is 'I wish
I never showed up'..."

"...and 10 is 'I'm ready to start right now', where are you?"

They say "probably a 6 or a 7."

"Sweet. What would it take to get you to a 10?"

And then the magic happens: they list their own closing conditions. You're
not persuading anymore. You're the order-taker for their list.

## Run this prompt

Paste this into your AI with this file:

```
My offer: [WHAT YOU OFFER AND WHO BUYS IT]

My price: [THE PRICE AND HOW IT'S BILLED]

Payment flexibility I can actually offer: [DEPOSITS, SPLIT PAYMENTS,
PLANS, OR "none"]

The questions and objections prospects stack on me: [LIST THE ONES YOU
HEAR, IN THEIR WORDS]

Using this file:

1. Write my isolation flush word for word: the best-customer relate line
   for my market, then the line that pulls every OTHER question onto the
   table before I answer the first one.
2. Write my money version: the belief-check question for my offer, then
   the pivot that turns "too expensive" into a payment structure I listed
   above. Never invent a plan I can't actually honor.
3. Write my 1-to-10 script with both anchors adapted to my offer, plus the
   follow-up that gets them listing their own closing conditions.
4. For the closing conditions my prospects are most likely to list, give
   me the order-taker response to each: no arguing, close off the
   condition, end in a question, close again.
```

Always got your back,
RyMac
