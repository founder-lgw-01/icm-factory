# Term Sheet

Every term from the video, in plain language. No question in the community
is too basic; this file exists so you never have to ask "wait, what's
DMARC?"

**At-bats** · Chances to close. A sales machine with no leads is a hitter
who never gets to the plate.

**Cold email** · Email to a stranger who never asked to hear from you. Done
right, it's how strangers raise their hand. Done wrong, it's spam.

**The law** · Once a lead is generated, it is a sales problem. Marketing
gets the lead. Sales gets the money. Everything in this video is marketing.

**Lead** · A stranger who raised their hand. The moment they reply "yes,"
they cross the line from marketing to sales.

**Campaign** · One organized sending run: 1 list, 1 sequence of emails,
1 goal.

**Reply rate** · Replies divided by emails delivered. Industry average is 1
percent. 3 is good. 6 is elite. My best ran 16.

**Lookalike domain (burner domain)** · A domain that resembles your real
one (getyourbrand.com) bought just for cold email. If it burns, your real
domain doesn't.

**Redirect** · The lookalike domain forwards visitors to your real site, so
anyone who checks it lands somewhere legit.

**Spam blacklist** · Lists the email providers use to block known spammers.
Land on one with your real domain and your whole business email is
radioactive.

**Mailbox** · One sending email address (ryan@getyourbrand.com). 3 per
domain, 30 cold sends a day each. Not negotiable.

**SPF / DKIM / DMARC** · 3 records on your domain that prove your email
really came from you. Set once per domain. Google and Yahoo reject mail
without them.

**Authentication** · The umbrella word for having SPF, DKIM, and DMARC in
place.

**Warmup** · Sending tiny, friendly amounts from a new mailbox for 4 to 6
weeks so providers learn to trust it before the real campaign.

**Pre-warmed accounts** · Mailboxes someone already warmed up for you. The
cheat code: you skip the 4 to 6 week line.

**Scrape** · Pulling a list of businesses or contacts from a source, like
a map or a database.

**Enrich** · Adding missing details to a scraped lead: email, phone, size,
whatever the scrape didn't include.

**Verify** · Checking that an email address actually exists and accepts
mail, BEFORE you send to it.

**Bounce** · An email that came back undeliverable. Over 3 percent bounces
on a list is a hard stop: do not send.

**Niche** · One specific type of business (roofers), not a category
(home services).

**Metro** · One city area. 1 niche in 1 metro at a time. Tight beats big.

**Lead magnet** · A free useful thing (tool, checklist, analysis) offered
in exchange for attention. The analyzer on my homepage is one.

**Tracking pixel** · An invisible image that reports when an email is
opened. Spam filters look for them. We don't use them.

**Plain text** · Email with no images, no formatting, no links. Looks like
a human typed it, because a human should have.

**Opener** · The first email in the sequence. 1 specific pain, 1 honest
question.

**Follow-up** · Emails 2 through 5, spread over weeks. 42 percent of all
replies come from these.

**Angle** · The reason-to-reply an email is built on. Every follow-up gets
a NEW one. "Just checking in" is not an angle.

**Soft ask** · A low-pressure question ("Want me to send it over?") instead
of a calendar link. Out-pulls the link almost 2 to 1.

**The handoff** · The moment a reply comes in and the lead moves from the
marketing machine to you, the salesperson.

**Speed to lead** · How fast a human answers a reply. The rule: within 5
minutes, or they're back on a roof, gone.

**The 15-minute call** · The 1 job of your first reply. Small ask, easy
yes, and the framework takes it from there.

**The framework** · The BuildMarketClose map of a sale, taught in the
earlier lessons: Pre-call, Rapport Building, Get a Commitment, Present,
Test Close, Close. A map of the conversation, not a script.

**Apollo / TrustedLeads / MillionVerifier** · The old way: 1 tool to
scrape, 1 to enrich, 1 to verify. 4 bills and up to a week of handoffs.

**Consulti** · The tool that collapses scrape, enrich, and verify into one
dashboard, plus lead magnets and AI copy. The one I run daily.

**Instantly** · The sending platform: it holds the campaigns, rotates the
mailboxes, and offers the pre-warmed accounts.

**Woosender** · Where my AI assistant worked leads by text and booked calls
prospects thought they'd booked with me. The machine WAS the demo.

**Affiliate** · I get paid if you buy through my link. Disclosed in the
video, disclosed here. I'd teach the same tools if I didn't.
