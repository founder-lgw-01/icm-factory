# Weave, Never Recite

Yo! It's RyMac. The first stage of my framework is the Lurk, and it happens
before you ever dial. 15 minutes of quiet recon. Their LinkedIn. Their
website. What they post, how they talk, what they're proud of.

Then you distill it to 1 page. And then you do the opposite of what feels
natural.

## The rule

**Weave, never recite.**

You never say "I did my homework on you." You never read their file out
loud. Nobody trusts a stranger who reads their file back to them. But
everybody remembers the one caller who did their homework.

The recon is not for showing off. It is for later. When they say "San
Diego," you already know you were in the Marines there. When they say
"Alabama," you already know you grew up in Louisiana. That's the Lurk
paying rent: you walk into Rapport already knowing where the overlap lives,
and the conversation just happens to go well.

Recite = "I saw on your LinkedIn that you played college ball." Creepy.
Weave = the overlap comes up on its own, because you steered there. Human.

## The name

One more thing before you dial: their name.

**The most important word in the English language is someone's name.**

Say it in the first 30 seconds. Naturally. Like a human. Not like a
telemarketer reading a script, and not zero times like a stranger who
doesn't care. Once, early, warm.

## Why the Lurk exists

Every stage is insurance for a later stage. The Lurk is insurance for
Rapport. Skip it and Rapport becomes weather talk, and weather talk builds
nothing.

## Run this prompt

Paste this into your AI with this file:

```
I'm prepping a sales call. Here's my raw recon on the prospect:

Prospect name: [NAME]
What they do: [FILL IN]
Notes from their LinkedIn: [PASTE ANYTHING: posts, job history, school,
city, what they brag about]
Notes from their website: [PASTE ANYTHING: about page, testimonials, tone,
what they seem proud of]
My offer: [FILL IN]

Using this file's method (weave, never recite):

1. Distill everything above into a 1-page lurk sheet: who they are, how
   they talk, what they're proud of, and where the overlap with me lives.
2. Write 3 weave lines: natural things I can say in conversation that USE
   the recon without ever revealing I researched them. Nothing that sounds
   like "I saw on your LinkedIn."
3. Flag anything in my notes I should NEVER bring up (too personal, too
   stalker-y).
4. Put their name at the top of the sheet in big letters, and give me 1
   natural way to use it in the first 30 seconds of the call.
```

Always got your back,
RyMac
