# The Duty To Close

Yo! It's RyMac. Most people who hate sales hate it because they think closing
is something you do TO somebody. Here is the reframe that fixes it, and it is
not a mindset trick, it is a condition.

## The picture

You've diagnosed they're dying of dehydration. It's your duty to close them on
the bottle of water you have.

Not your option. Your duty.

Because if you let them walk, they are still dying of dehydration. And you had
the water.

You should have done everything in your power to help. If they didn't come to
the conclusion you had the bottle of water they desperately needed, **you
failed as a closer and you were just another salesman.**

## Why that last line matters

It turns the duty into something you can FAIL. That is the difference between a
principle and a standard.

A principle is "closing is helping." Nice. Nobody changes anything.

A standard is "if they walked away still thirsty, that is on me." Now you go
back and look at what you did not ask, what you did not surface, and where you
let them talk themselves out of it while you nodded politely.

## The other half, or this becomes the thing you hate

**Closers earn the credit card, they don't trick them into a swipe.**

The duty only exists once you have diagnosed the dehydration. No diagnosis, no
duty. If you skip straight to "it is my duty to close everybody," you have
rebuilt the exact pushy salesman this whole course is against, just with a
nicer story about it.

Diagnose first. Then the duty is real.

## Run this prompt

```
You are pressure-testing whether I have earned the duty to close.

WHAT I OFFER: [plain words]
WHO IT IS FOR: [industry and role]
THE PROBLEM IT FIXES: [in THEIR words]
WHAT IT COSTS THEM TO NOT FIX IT: [money, time, or risk. Be specific. If I
cannot answer this, say so plainly.]
WHAT IT COSTS: [my price]
WHAT I ACTUALLY DELIVER: [the real work, not the pitch]

Do this:

1. Tell me straight: is the problem I named actually painful enough that
   somebody is "dying of thirst" over it? Or is it a nice-to-have I am dressing
   up? Do not be polite about this.

2. If the answer is yes, write the 3 diagnostic questions I must ask on a call
   BEFORE I have earned the right to close. Each one should make them say the
   pain out loud in their own words, not mine.

3. If the answer is no, tell me what would have to change about the offer, the
   buyer, or the price for the duty to be real.

4. Give me the 1 sentence I say to myself before a call to check I have
   diagnosed before I close.

Rule: I would rather hear that my offer is weak than be told to push harder.
```
